import express from 'express';
import type { Request, Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createServer as createViteServer } from 'vite';

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const ROOT = process.cwd();
const STATE_FILE = path.resolve(process.env.LUDITO_STATE_FILE || path.join(ROOT, '.ludito-state.json'));
const ADMIN_PASSWORD = process.env.LUDITO_ADMIN_PASSWORD || 'tiomario#2026Admin$*';
const COLORS = new Set(['Morado', 'Amarillo', 'Celeste', 'Rojo', 'Verde', 'Naranja']);

interface User {
  name: string;
  role: 'client' | 'host';
}

interface OrderItem {
  color: string;
  quantity: number;
}

interface LuditoEvent {
  id: string;
  type: 'order' | 'round_closed' | 'round_started';
  name?: string;
  items?: OrderItem[];
  color?: string;
  quantity?: number;
  round: number;
  timestamp: string;
}

interface ChatMessage {
  id: string;
  name: string;
  text: string;
  timestamp: string;
}

interface VoicePreference {
  voiceURI: string;
  lang: string;
  name: string;
  volume: number;
}

interface LuditoState {
  events: LuditoEvent[];
  chat: ChatMessage[];
  voicePreference: VoicePreference | null;
  round: number;
  accepting: boolean;
  roundCapacity: number | null;
}

const USERS = new Map<string, User>([
  ['0412', { name: 'Invitado', role: 'client' }],
  ['1234', { name: 'María P.', role: 'client' }],
  ['5678', { name: 'Esther', role: 'client' }],
]);

const SESSIONS_FILE = path.resolve(path.join(ROOT, '.ludito-sessions.json'));

function readInitialSessions(): Map<string, User> {
  const map = new Map<string, User>();
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const data = JSON.parse(fs.readFileSync(SESSIONS_FILE, 'utf8'));
      for (const [token, user] of Object.entries(data)) {
        map.set(token, user as User);
      }
    }
  } catch (err) {
    console.error('Error reading sessions file:', err);
  }
  return map;
}

const sessions = readInitialSessions();
const listeners = new Set<Response>();

async function persistSessions() {
  try {
    const obj: Record<string, User> = {};
    for (const [token, user] of sessions.entries()) {
      obj[token] = user;
    }
    await fs.promises.writeFile(SESSIONS_FILE, JSON.stringify(obj, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to write sessions file:', err);
  }
}

function readInitialState(): LuditoState {
  try {
    if (fs.existsSync(STATE_FILE)) {
      const saved = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
      if (Array.isArray(saved.events)) {
        return {
          events: saved.events.slice(-250),
          chat: Array.isArray(saved.chat) ? saved.chat.slice(-150) : [],
          voicePreference: saved.voicePreference || null,
          round: Number.isInteger(saved.round) && saved.round > 0 ? saved.round : 1,
          accepting: saved.accepting !== false,
          roundCapacity: typeof saved.roundCapacity === 'number' && saved.roundCapacity > 0 ? saved.roundCapacity : null,
        };
      }
    }
  } catch (err) {
    console.error('Error reading initial state:', err);
  }
  return { events: [], chat: [], voicePreference: null, round: 1, accepting: true, roundCapacity: null };
}

let state: LuditoState = readInitialState();

function currentUser(req: Request): User | undefined {
  const authorization = req.headers.authorization || '';
  const token = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
  return sessions.get(token);
}

function matchesAdminPassword(candidate?: string): boolean {
  try {
    const expectedHash = crypto.createHash('sha256').update(ADMIN_PASSWORD, 'utf8').digest();
    const candidateHash = crypto.createHash('sha256').update(String(candidate || ''), 'utf8').digest();
    return crypto.timingSafeEqual(candidateHash, expectedHash);
  } catch {
    return false;
  }
}

async function persistAndBroadcast(): Promise<void> {
  try {
    await fs.promises.writeFile(STATE_FILE, JSON.stringify(state, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to write state file:', err);
  }
  const message = `event: state\ndata: ${JSON.stringify(state)}\n\n`;
  for (const client of listeners) {
    try {
      client.write(message);
    } catch {
      listeners.delete(client);
    }
  }
}

function appendEvent(event: LuditoEvent): void {
  state.events.push(event);
  state.events = state.events.slice(-250);
  if (event.type === 'round_closed' && event.round === state.round) {
    state.accepting = false;
  }
  if (event.type === 'round_started' && event.round > state.round) {
    state.round = event.round;
    state.accepting = true;
  }
}

function getRoundOrderedQuantity(round: number, color: string): number {
  let total = 0;
  for (const event of state.events) {
    if (event.type === 'order' && event.round === round && Array.isArray(event.items)) {
      for (const item of event.items) {
        if (item.color === color) {
          total += item.quantity;
        }
      }
    }
  }
  return total;
}

async function startServer() {
  const app = express();

  app.use(express.json({ limit: '64kb' }));

  // API Config
  app.get('/api/config', (_req, res) => {
    res.json({
      streamUrl: process.env.LUDITO_STREAM_URL || '',
      whatsappNumber: process.env.LUDITO_WHATSAPP_NUMBER || '',
    });
  });

  // API State
  app.get('/api/state', (_req, res) => {
    res.json(state);
  });

  // SSE Stream
  app.get('/api/events', (_req, res) => {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'Access-Control-Allow-Origin': '*',
    });
    res.write(`event: snapshot\ndata: ${JSON.stringify(state)}\n\n`);
    listeners.add(res);

    _req.on('close', () => {
      listeners.delete(res);
    });
  });

  // Participant Auth by PIN
  app.post('/api/auth', async (req, res) => {
    const { pin } = req.body;
    if (!/^\d{4}$/.test(String(pin || ''))) {
      res.status(401).json({ error: 'El PIN debe tener cuatro dígitos.' });
      return;
    }
    const user = USERS.get(String(pin || ''));
    if (!user) {
      res.status(401).json({ error: 'PIN incorrecto. Usa 0412 o 1234.' });
      return;
    }
    if (user.role === 'host') {
      res.status(403).json({ error: 'Usa la contraseña de administrador para entrar al panel.' });
      return;
    }
    const token = crypto.randomBytes(24).toString('hex');
    sessions.set(token, user);
    await persistSessions();
    res.json({ token, user: user.name, role: user.role });
  });

  // Host Auth by Password
  app.post('/api/admin/auth', async (req, res) => {
    const { password } = req.body;
    if (!matchesAdminPassword(password)) {
      res.status(401).json({ error: 'Contraseña incorrecta.' });
      return;
    }
    const user: User = { name: 'Tío Mario', role: 'host' };
    const token = crypto.randomBytes(32).toString('hex');
    sessions.set(token, user);
    await persistSessions();
    res.json({ token, user: user.name, role: user.role });
  });

  // Check Admin Session
  app.get('/api/admin/session', (req, res) => {
    const user = currentUser(req);
    if (!user || user.role !== 'host') {
      res.status(401).json({ error: 'La sesión de administrador no es válida.' });
      return;
    }
    res.json({ user: user.name, role: user.role });
  });

  // Order Submission
  app.post('/api/orders', async (req, res) => {
    const user = currentUser(req);
    if (!user) {
      res.status(401).json({ error: 'Inicia sesión para enviar un pedido.' });
      return;
    }
    const { items } = req.body;
    if (!state.accepting) {
      res.status(409).json({ error: 'Los pedidos de esta ronda están cerrados.' });
      return;
    }
    const validItems =
      Array.isArray(items) &&
      items.length > 0 &&
      items.length <= COLORS.size &&
      items.every(
        (item, index) =>
          COLORS.has(item.color) &&
          Number.isInteger(item.quantity) &&
          item.quantity >= 1 &&
          item.quantity <= 20 &&
          items.findIndex((candidate) => candidate.color === item.color) === index,
      );

    if (!validItems) {
      res.status(400).json({ error: 'Pedido no válido.' });
      return;
    }

    const normalizedItems = items.map(({ color, quantity }) => ({ color, quantity }));

    if (state.roundCapacity != null && state.roundCapacity > 0) {
      for (const item of normalizedItems) {
        const ordered = getRoundOrderedQuantity(state.round, item.color);
        const available = state.roundCapacity - ordered;
        if (item.quantity > available) {
          res.status(409).json({
            error: `No hay suficientes espacios para ${item.color}. ${available <= 0 ? 'Color agotado en esta ronda.' : `Solo quedan ${available} espacios.`}`,
          });
          return;
        }
      }
    }
    const event: LuditoEvent = {
      id: crypto.randomUUID(),
      type: 'order',
      name: user.name,
      items: normalizedItems,
      round: state.round,
      timestamp: new Date().toISOString(),
    };

    appendEvent(event);
    await persistAndBroadcast();
    res.status(201).json({ event, state });
  });

  // Chat
  app.post('/api/chat', async (req, res) => {
    const user = currentUser(req);
    if (!user) {
      res.status(401).json({ error: 'Inicia sesión para enviar mensajes.' });
      return;
    }
    const { message } = req.body;
    const text = typeof message === 'string' ? message.trim() : '';
    if (!text || text.length > 500) {
      res.status(400).json({ error: 'El mensaje debe tener entre 1 y 500 caracteres.' });
      return;
    }
    const chatMessage: ChatMessage = {
      id: crypto.randomUUID(),
      name: user.name,
      text,
      timestamp: new Date().toISOString(),
    };
    state.chat.push(chatMessage);
    state.chat = state.chat.slice(-150);
    await persistAndBroadcast();
    res.status(201).json({ message: chatMessage });
  });

  // Voice Preference (Host only)
  app.post('/api/voice', async (req, res) => {
    const user = currentUser(req);
    if (!user || user.role !== 'host') {
      res.status(403).json({ error: 'Solo el host puede cambiar la voz.' });
      return;
    }
    const { preference } = req.body;
    const voiceURI = typeof preference?.voiceURI === 'string' ? preference.voiceURI.slice(0, 500) : '';
    const lang = typeof preference?.lang === 'string' && /^es([_-]|$)/i.test(preference.lang) ? preference.lang.slice(0, 20) : 'es-MX';
    const name = typeof preference?.name === 'string' ? preference.name.slice(0, 120) : 'Voz automática (español)';
    const volume = Number.isFinite(Number(preference?.volume)) ? Math.min(1, Math.max(0, Number(preference.volume))) : 1;
    state.voicePreference = { voiceURI, lang, name, volume };
    await persistAndBroadcast();
    res.json({ voicePreference: state.voicePreference });
  });

  // Toggle Round (Host only)
  app.post('/api/rounds/toggle', async (req, res) => {
    const user = currentUser(req);
    if (!user || user.role !== 'host') {
      res.status(403).json({ error: 'Solo el host puede controlar las rondas.' });
      return;
    }
    const event: LuditoEvent = state.accepting
      ? { id: crypto.randomUUID(), type: 'round_closed', round: state.round, timestamp: new Date().toISOString() }
      : { id: crypto.randomUUID(), type: 'round_started', round: state.round + 1, timestamp: new Date().toISOString() };
    appendEvent(event);
    await persistAndBroadcast();
    res.json({ event, state });
  });

  // Set Round Capacity (Host only)
  app.post('/api/rounds/capacity', async (req, res) => {
    const user = currentUser(req);
    if (!user || user.role !== 'host') {
      res.status(403).json({ error: 'Solo el host puede configurar los espacios por color.' });
      return;
    }
    const { capacity } = req.body;
    const num = Number(capacity);
    if (capacity === null || capacity === '' || capacity === undefined || isNaN(num) || num <= 0) {
      state.roundCapacity = null;
    } else {
      state.roundCapacity = Math.min(999, Math.max(1, Math.floor(num)));
    }
    await persistAndBroadcast();
    res.json({ state, roundCapacity: state.roundCapacity });
  });

  // Clear Chat Only (Host only)
  app.post('/api/admin/clear-chat', async (req, res) => {
    const user = currentUser(req);
    if (!user || user.role !== 'host') {
      res.status(403).json({ error: 'Solo el host puede limpiar el chat.' });
      return;
    }
    const removedChatMessages = state.chat.length;
    state.chat = [];
    await persistAndBroadcast();
    res.json({ state, removedChatMessages });
  });

  // Reset Live State (Host only)
  app.post('/api/admin/reset-live', async (req, res) => {
    const user = currentUser(req);
    if (!user || user.role !== 'host') {
      res.status(403).json({ error: 'Solo Tío Mario puede reiniciar la transmisión.' });
      return;
    }
    const removedOrders = state.events.filter((event) => event.type === 'order').length;
    const removedChatMessages = state.chat.length;
    state.events = [];
    state.chat = [];
    state.round = 1;
    state.accepting = true;
    state.roundCapacity = null;
    await persistAndBroadcast();
    res.json({ state, removedOrders, removedChatMessages });
  });

  // Logout
  app.post('/api/logout', async (req, res) => {
    const authorization = req.headers.authorization || '';
    const token = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
    sessions.delete(token);
    await persistSessions();
    res.json({ ok: true });
  });

  // 25-second keepalive for SSE
  setInterval(() => {
    for (const client of listeners) {
      try {
        client.write(': ping\n\n');
      } catch {
        listeners.delete(client);
      }
    }
  }, 25000);

  // Frontend serving
  if (process.env.NODE_ENV === 'production' && fs.existsSync(path.resolve(ROOT, 'dist'))) {
    app.use(express.static(path.resolve(ROOT, 'dist')));
    app.get('/admin.html', (_req, res) => {
      res.sendFile(path.resolve(ROOT, 'dist/admin.html'));
    });
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(ROOT, 'dist/index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, HOST, () => {
    console.log(`Ludito Live escuchando en http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Error starting server:', err);
  process.exit(1);
});
