const previewOverlay = document.querySelector('#preview-overlay');
const previewCountdown = document.querySelector('#preview-countdown');
const screensaverScreen = document.querySelector('#screensaver-screen');
const screensaverClose = document.querySelector('#screensaver-close');
const accessScreen = document.querySelector('#access-screen');
const accessButton = document.querySelector('#pin-access-button');
const accessClose = document.querySelector('#access-close');
const loginForm = document.querySelector('#login-form');
const pinInput = document.querySelector('#pin-input');
const loginMessage = document.querySelector('#login-message');
const whatsappLink = document.querySelector('#whatsapp-link');
const clientVideo = document.querySelector('#client-video');
const audioEnableButton = document.querySelector('#audio-enable-button');
const clientAudioIcon = document.querySelector('#client-audio-icon');
const clientAudioLabel = document.querySelector('#client-audio-label');
const connectObsButton = document.querySelector('#connect-obs-button');
const streamPlaceholder = document.querySelector('#stream-placeholder');
const streamStatus = document.querySelector('#stream-status');
const clientOrder = document.querySelector('#client-order');
const userLabel = document.querySelector('#user-label');
const submitButton = document.querySelector('#submit-order');
const orderMessage = document.querySelector('#order-message');
const clientClosed = document.querySelector('#client-closed');
const roundLabel = document.querySelector('#client-round');
const clientRoundCapacity = document.querySelector('#client-round-capacity');
const feedList = document.querySelector('#feed-list');
const feedEmpty = document.querySelector('#feed-empty');
const feedCount = document.querySelector('#feed-count');
const colorRows = [...document.querySelectorAll('.client-color-row')];
const selectionTotal = document.querySelector('#selection-total');
const chatList = document.querySelector('#client-chat-list');
const chatEmpty = document.querySelector('#client-chat-empty');
const chatForm = document.querySelector('#client-chat-form');
const chatInput = document.querySelector('#client-chat-input');
const chatSend = document.querySelector('#client-chat-send');
const chatStatus = document.querySelector('#client-chat-status');
const voiceToggle = document.querySelector('#client-voice-toggle');
const voiceVolume = document.querySelector('#client-voice-volume');
const voiceVolumeValue = document.querySelector('#client-voice-volume-value');
const speechQueue = window.Ludito.createSpeechQueue();
const seenChatIds = new Set();
speechQueue.setEnabled(voiceToggle.checked);

const PIN_USERS = Object.freeze({
  '0412': 'Invitado',
  '1234': 'María P.'
});

const selectedQuantities = new Map(colorRows.map((row) => [row.dataset.color, 0]));
let acceptingOrders = true;
let authenticated = false;
let activeUserName = '';
let currentState = { events: [], round: 1, accepting: true };
let voicePreference = null;
let localVoiceVolume = Number(localStorage.getItem('ludito-client-voice-volume') ?? 1);
localVoiceVolume = Math.min(1, Math.max(0, Number.isFinite(localVoiceVolume) ? localVoiceVolume : 1));
const previewDeadline = 15000;
let previewExpired = false;
let screensaverDismissed = false;

function colorClass(color) {
  return ({ Morado: 'purple', Amarillo: 'yellow', Celeste: 'sky', Rojo: 'red', Verde: 'green', Naranja: 'orange' })[color] || '';
}

function renderState(state, isLiveUpdate = false) {
  currentState = state;
  if (!state.chat || state.chat.length === 0) {
    seenChatIds.clear();
    speechQueue.clear();
  }
  voicePreference = state.voicePreference || null;
  speechQueue.setVoicePreference({ ...voicePreference, volume: localVoiceVolume });
  const orders = state.events.filter((event) => event.type === 'order');
  feedList.replaceChildren(feedEmpty);
  feedEmpty.hidden = state.events.length > 0;
  feedCount.textContent = `${orders.length} ${orders.length === 1 ? 'pedido' : 'pedidos'}`;
  roundLabel.textContent = `RONDA ${state.round}`;
  acceptingOrders = state.accepting;
  clientClosed.hidden = acceptingOrders;

  state.events.forEach((event) => {
    if (event.type !== 'order') {
      const marker = document.createElement('div');
      marker.className = 'client-round-marker';
      marker.dataset.closed = String(event.type === 'round_closed');
      marker.textContent = event.type === 'round_closed' ? `Pedidos cerrados · Ronda ${event.round}` : `Inicio de Ronda ${event.round}`;
      feedList.append(marker);
      return;
    }

    const row = document.createElement('div');
    row.className = 'client-feed-row';
    const name = document.createElement('strong');
    name.textContent = event.name;
    const summary = document.createElement('span');
    summary.className = 'client-feed-summary';
    const orderText = document.createElement('span');
    const items = Array.isArray(event.items) ? event.items : [{ color: event.color, quantity: event.quantity }];
    orderText.textContent = `pidió ${items.map((item) => `${item.quantity} ${item.color}`).join(' · ')}`;
    summary.append(orderText);
    const time = document.createElement('time');
    time.dateTime = event.timestamp;
    time.textContent = new Intl.DateTimeFormat('es', { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date(event.timestamp));
    row.append(name, summary, time);
    feedList.append(row);
  });
  feedList.scrollTop = feedList.scrollHeight;
  renderChat(state.chat || [], isLiveUpdate);
  updateOrderControls();
}

function renderChat(messages, isLiveUpdate) {
  chatList.replaceChildren(chatEmpty);
  chatEmpty.hidden = messages.length > 0;
  messages.forEach((message) => {
    if (isLiveUpdate && !seenChatIds.has(message.id) && voiceToggle.checked) {
      speechQueue.speak(`${message.name} dice: ${message.text}`);
    }
    seenChatIds.add(message.id);
    const row = document.createElement('article');
    row.className = 'client-chat-message';
    const header = document.createElement('div');
    header.className = 'client-chat-message-header';
    const name = document.createElement('strong');
    name.textContent = message.name;
    const time = document.createElement('time');
    time.dateTime = message.timestamp;
    time.textContent = new Intl.DateTimeFormat('es', { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date(message.timestamp));
    const text = document.createElement('p');
    text.textContent = message.text;
    header.append(name, time);
    row.append(header, text);
    chatList.append(row);
  });
  chatList.scrollTop = chatList.scrollHeight;
}

function updateOrderControls() {
  let totalQuantity = 0;

  // Count already ordered colors in the active round
  const currentRoundOrders = (currentState.events || []).filter(
    (e) => e.type === 'order' && e.round === currentState.round
  );
  const colorOrderedMap = new Map();
  currentRoundOrders.forEach((e) => {
    const items = Array.isArray(e.items) ? e.items : [{ color: e.color, quantity: e.quantity }];
    items.forEach((item) => {
      colorOrderedMap.set(item.color, (colorOrderedMap.get(item.color) || 0) + (item.quantity || 1));
    });
  });

  const hasLimit = typeof currentState.roundCapacity === 'number' && currentState.roundCapacity > 0;

  if (clientRoundCapacity) {
    if (hasLimit) {
      clientRoundCapacity.textContent = `${currentState.roundCapacity} cupos / color`;
      clientRoundCapacity.classList.add('has-limit');
    } else {
      clientRoundCapacity.textContent = 'Cupos libres';
      clientRoundCapacity.classList.remove('has-limit');
    }
  }

  colorRows.forEach((row) => {
    const color = row.dataset.color;
    const tag = row.querySelector('[data-capacity-tag]');
    const alreadyOrdered = colorOrderedMap.get(color) || 0;
    const availableInRound = hasLimit ? Math.max(0, currentState.roundCapacity - alreadyOrdered) : 20;

    if (tag) {
      if (hasLimit) {
        if (availableInRound === 0) {
          tag.textContent = 'Agotado';
          tag.className = 'color-capacity-tag sold-out';
        } else if (availableInRound <= 3) {
          tag.textContent = `¡Últimos ${availableInRound}!`;
          tag.className = 'color-capacity-tag low-stock';
        } else {
          tag.textContent = `${availableInRound} libres`;
          tag.className = 'color-capacity-tag in-stock';
        }
      } else {
        tag.textContent = 'Sin límite';
        tag.className = 'color-capacity-tag unlimited';
      }
    }

    let amount = selectedQuantities.get(color) || 0;
    if (hasLimit && amount > availableInRound) {
      amount = availableInRound;
      selectedQuantities.set(color, amount);
    }

    totalQuantity += amount;
    row.querySelector('output').textContent = String(amount);
    row.dataset.selected = String(amount > 0);
    row.dataset.soldOut = String(hasLimit && availableInRound === 0);

    row.querySelectorAll('button').forEach((button) => {
      const step = Number(button.dataset.step);
      if (step < 0) {
        button.disabled = !acceptingOrders || amount === 0;
      } else {
        const maxLimit = hasLimit ? Math.min(20, availableInRound) : 20;
        button.disabled = !acceptingOrders || amount >= maxLimit || (hasLimit && availableInRound === 0);
      }
    });
  });

  selectionTotal.textContent = `${totalQuantity} ${totalQuantity === 1 ? 'cupo seleccionado' : 'cupos seleccionados'}`;
  submitButton.disabled = !authenticated || totalQuantity === 0 || !acceptingOrders;
}

function unlockClient(user) {
  authenticated = true;
  activeUserName = user;
  sessionStorage.setItem('ludito-client-user', user);
  accessScreen.hidden = true;
  screensaverScreen.hidden = true;
  previewOverlay.hidden = true;
  clientOrder.hidden = false;
  userLabel.textContent = user.toUpperCase();
  chatInput.disabled = false;
  chatSend.disabled = false;
  chatStatus.textContent = 'Conectado al chat';
  pinInput.value = '';
  updateOrderControls();
}

function dismissScreensaver() {
  screensaverDismissed = true;
  screensaverScreen.hidden = true;
  document.body.dataset.mode = 'spectator';
}

function openPinAccess() {
  if (authenticated) return;
  screensaverScreen.hidden = true;
  previewOverlay.hidden = true;
  accessScreen.hidden = false;
  document.body.dataset.mode = 'pin-access';
  pinInput.focus({ preventScroll: true });
}

function closePinAccess() {
  accessScreen.hidden = true;
  if (!authenticated && previewExpired && !screensaverDismissed) screensaverScreen.hidden = false;
  else if (!authenticated && !previewExpired) previewOverlay.hidden = false;
  if (!authenticated && screensaverDismissed) document.body.dataset.mode = 'spectator';
}

screensaverClose.addEventListener('click', dismissScreensaver);
screensaverScreen.addEventListener('click', (event) => {
  if (event.target === screensaverScreen) dismissScreensaver();
});

accessButton.addEventListener('click', openPinAccess);
accessClose.addEventListener('click', closePinAccess);
accessScreen.addEventListener('click', (event) => {
  if (event.target === accessScreen) closePinAccess();
});

function updatePreviewTimer() {
  const remaining = Math.max(0, previewDeadline - performance.now());
  previewCountdown.textContent = String(Math.ceil(remaining / 1000));
  if (remaining > 0) return;

  previewExpired = true;
  previewOverlay.hidden = true;
  if (!authenticated && !screensaverDismissed && accessScreen.hidden) screensaverScreen.hidden = false;
  window.clearInterval(previewTimer);
}

const previewTimer = window.setInterval(updatePreviewTimer, 100);
updatePreviewTimer();

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  loginMessage.textContent = '';
  const pin = pinInput.value.trim();
  if (!/^\d{4}$/.test(pin) || !PIN_USERS[pin]) {
    loginMessage.textContent = 'PIN no registrado. Verifica los cuatro dígitos.';
    pinInput.setAttribute('aria-invalid', 'true');
    pinInput.focus();
    return;
  }
  try {
    const session = await window.Ludito.authenticate(pin);
    if (session.role !== 'client') {
      window.Ludito.logout();
      throw new Error('Usa el acceso de cliente para enviar pedidos.');
    }
    if (session.user !== PIN_USERS[pin]) throw new Error('El usuario del PIN no coincide con el registro.');
    unlockClient(session.user);
  } catch (error) {
    loginMessage.textContent = error.message;
    pinInput.setAttribute('aria-invalid', 'true');
    pinInput.focus();
  }
});

pinInput.addEventListener('input', () => {
  loginMessage.textContent = '';
  pinInput.removeAttribute('aria-invalid');
});

colorRows.forEach((row) => {
  row.querySelectorAll('button').forEach((button) => {
    button.addEventListener('click', () => {
      const color = row.dataset.color;
      const step = Number(button.dataset.step);
      const currentVal = selectedQuantities.get(color) || 0;

      const currentRoundOrders = (currentState.events || []).filter(
        (e) => e.type === 'order' && e.round === currentState.round
      );
      let alreadyOrdered = 0;
      currentRoundOrders.forEach((e) => {
        const items = Array.isArray(e.items) ? e.items : [{ color: e.color, quantity: e.quantity }];
        items.forEach((item) => {
          if (item.color === color) alreadyOrdered += (item.quantity || 1);
        });
      });

      const hasLimit = typeof currentState.roundCapacity === 'number' && currentState.roundCapacity > 0;
      const maxAvailable = hasLimit ? Math.max(0, currentState.roundCapacity - alreadyOrdered) : 20;
      const maxSelectable = hasLimit ? Math.min(20, maxAvailable) : 20;

      const nextValue = Math.max(0, Math.min(maxSelectable, currentVal + step));
      selectedQuantities.set(color, nextValue);
      orderMessage.textContent = '';
      updateOrderControls();
    });
  });
});

submitButton.addEventListener('click', async () => {
  if (submitButton.disabled) return;
  submitButton.disabled = true;
  try {
    const items = [...selectedQuantities]
      .filter(([, amount]) => amount > 0)
      .map(([color, amount]) => ({ color, quantity: amount }));
    await window.Ludito.submitOrder(items);
    orderMessage.textContent = 'Pedido registrado.';
    selectedQuantities.forEach((_, color) => selectedQuantities.set(color, 0));
  } catch (error) {
    orderMessage.textContent = error.message;
  } finally {
    updateOrderControls();
  }
});

chatForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const message = chatInput.value.trim();
  if (!authenticated || !message) return;
  chatInput.disabled = true;
  chatSend.disabled = true;
  try {
    await window.Ludito.sendChat(message);
    chatInput.value = '';
    chatStatus.textContent = 'Mensaje enviado.';
  } catch (error) {
    chatStatus.textContent = error.message;
  } finally {
    chatInput.disabled = !authenticated;
    chatSend.disabled = !authenticated;
    if (authenticated) chatInput.focus();
  }
});

window.Ludito.subscribe(renderState, (connected) => {
  if (!connected) streamStatus.textContent = 'Reconectando al registro';
});

window.Ludito.onSpanishVoicesChanged(() => {});

voiceToggle.addEventListener('change', () => {
  speechQueue.setEnabled(voiceToggle.checked);
});

function renderClientVolume() {
  voiceVolume.value = String(localVoiceVolume);
  voiceVolumeValue.value = `${Math.round(localVoiceVolume * 100)}%`;
  voiceVolumeValue.textContent = `${Math.round(localVoiceVolume * 100)}%`;
}

voiceVolume.addEventListener('input', () => {
  localVoiceVolume = Number(voiceVolume.value);
  localStorage.setItem('ludito-client-voice-volume', String(localVoiceVolume));
  speechQueue.setVoicePreference({ ...voicePreference, volume: localVoiceVolume });
  renderClientVolume();
});

renderClientVolume();

let obsStream = null;

async function startObsCapture() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    streamStatus.textContent = 'Navegador sin soporte para captura de video';
    return;
  }

  streamStatus.textContent = 'Solicitando señal de cámara / OBS...';

  // Check if an OBS or virtual camera is listed
  let videoConstraint = true;
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const videoDevices = devices.filter((d) => d.kind === 'videoinput');
    const obsDevice = videoDevices.find((d) => /obs|virtual/i.test(d.label));
    if (obsDevice && obsDevice.deviceId) {
      videoConstraint = { deviceId: { ideal: obsDevice.deviceId } };
    }
  } catch {
    videoConstraint = true;
  }

  let stream = null;
  // Step 1: Request video and audio as specified in getUserMedia({ video: true, audio: true })
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: videoConstraint, audio: true });
  } catch (errAudio) {
    console.warn('getUserMedia con audio no disponible, intentando solo video:', errAudio);
    try {
      // Step 2: Fallback to video only if microphone is unavailable/blocked
      stream = await navigator.mediaDevices.getUserMedia({ video: videoConstraint, audio: false });
    } catch (errVideo) {
      console.warn('getUserMedia falló:', errVideo);
      streamStatus.textContent = 'Permiso de cámara requerido para OBS';
      if (connectObsButton) {
        connectObsButton.textContent = 'Permitir Cámara / OBS';
        connectObsButton.hidden = false;
      }
      return;
    }
  }

  if (stream) {
    obsStream = stream;
    clientVideo.srcObject = stream;
    clientVideo.playsInline = true;
    clientVideo.autoplay = true;
    // Mute initially to guarantee autoplay without browser policy rejection
    clientVideo.muted = true;

    try {
      await clientVideo.play();
      streamPlaceholder.hidden = true;
      streamStatus.textContent = 'Señal OBS conectada (En vivo)';
      updateClientAudioUI();
    } catch (playError) {
      console.warn('Reproducción de video bloqueada:', playError);
      streamStatus.textContent = 'Toca el botón para ver la señal';
      if (connectObsButton) {
        connectObsButton.textContent = 'Iniciar Video OBS';
        connectObsButton.hidden = false;
      }
    }
  }
}

function updateClientAudioUI() {
  const isMuted = clientVideo.muted || clientVideo.volume === 0;
  if (clientAudioIcon) clientAudioIcon.textContent = isMuted ? '🔇' : '🔊';
  if (clientAudioLabel) clientAudioLabel.textContent = isMuted ? 'Activar sonido' : 'Silenciar';
  audioEnableButton.classList.toggle('unmuted', !isMuted);
}

if (connectObsButton) {
  connectObsButton.addEventListener('click', () => {
    startObsCapture();
  });
}

clientVideo.addEventListener('playing', () => {
  streamPlaceholder.hidden = true;
  if (!streamStatus.textContent.includes('OBS')) {
    streamStatus.textContent = 'Señal conectada';
  }
  updateClientAudioUI();
});

clientVideo.addEventListener('error', () => {
  if (!obsStream) {
    startObsCapture();
  } else {
    streamStatus.textContent = 'No se pudo abrir la señal';
  }
});

audioEnableButton.addEventListener('click', async () => {
  if (clientVideo.muted) {
    clientVideo.muted = false;
    try {
      await clientVideo.play();
    } catch {
      clientVideo.muted = true;
    }
  } else {
    clientVideo.muted = true;
  }
  updateClientAudioUI();
});

clientVideo.addEventListener('volumechange', updateClientAudioUI);

Promise.all([window.Ludito.fetchConfig(), window.Ludito.fetchState()]).then(([config, state]) => {
  if (config.streamUrl) {
    clientVideo.src = config.streamUrl;
    clientVideo.addEventListener('error', () => {
      startObsCapture();
    }, { once: true });
  } else {
    // Modo de prueba local con OBS: captura automáticamente la señal
    startObsCapture();
  }
  if (config.whatsappNumber) whatsappLink.href = `https://wa.me/${config.whatsappNumber}?text=Hola%2C%20quiero%20solicitar%20un%20PIN%20para%20Ludito.`;
  renderState(state);
}).catch(() => {
  startObsCapture();
  streamStatus.textContent = 'Conecta con el servidor para participar';
});
