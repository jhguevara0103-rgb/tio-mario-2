(() => {
  const ADMIN_TOKEN_KEY = 'ludito-admin-session-token';
  let token = window.location.pathname.endsWith('/admin.html')
    ? sessionStorage.getItem(ADMIN_TOKEN_KEY) || ''
    : '';
  let eventSource = null;

  async function request(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...options.headers };
    if (token) headers.Authorization = `Bearer ${token}`;
    const response = await fetch(path, { ...options, headers });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || `Error ${response.status}`);
    return payload;
  }

  async function authenticate(pin) {
    const result = await request('/api/auth', { method: 'POST', body: JSON.stringify({ pin }) });
    token = result.token;
    return result;
  }

  async function authenticateAdmin(password) {
    const result = await request('/api/admin/auth', { method: 'POST', body: JSON.stringify({ password }) });
    token = result.token;
    sessionStorage.setItem(ADMIN_TOKEN_KEY, token);
    return result;
  }

  async function restoreAdminSession() {
    token = sessionStorage.getItem(ADMIN_TOKEN_KEY) || '';
    if (!token) return null;
    try {
      const session = await request('/api/admin/session');
      if (session.role !== 'host') throw new Error('Invalid host session');
      return session;
    } catch {
      token = '';
      sessionStorage.removeItem(ADMIN_TOKEN_KEY);
      return null;
    }
  }

  async function fetchConfig() {
    return request('/api/config');
  }

  async function fetchState() {
    return request('/api/state');
  }

  function subscribe(onState, onConnection = () => {}) {
    if (eventSource) eventSource.close();
    eventSource = new EventSource('/api/events');
    eventSource.addEventListener('open', () => onConnection(true));
    eventSource.addEventListener('error', () => onConnection(false));
    eventSource.addEventListener('snapshot', (event) => {
      try { onState(JSON.parse(event.data), false); } catch { /* Ignore malformed event payloads. */ }
    });
    eventSource.addEventListener('state', (event) => {
      try { onState(JSON.parse(event.data), true); } catch { /* Ignore malformed event payloads. */ }
    });
    return () => eventSource?.close();
  }

  async function submitOrder(items) {
    return request('/api/orders', { method: 'POST', body: JSON.stringify({ items }) });
  }

  async function toggleRound() {
    return request('/api/rounds/toggle', { method: 'POST', body: '{}' });
  }

  async function resetLiveState() {
    return request('/api/admin/reset-live', { method: 'POST', body: '{}' });
  }

  async function sendChat(message) {
    return request('/api/chat', { method: 'POST', body: JSON.stringify({ message }) });
  }

  async function saveVoicePreference(preference) {
    return request('/api/voice', { method: 'POST', body: JSON.stringify({ preference }) });
  }

  function getSpanishVoices() {
    if (!('speechSynthesis' in window)) return [];
    return window.speechSynthesis.getVoices().filter((voice) => /^es([_-]|$)/i.test(voice.lang));
  }

  function onSpanishVoicesChanged(callback) {
    if (!('speechSynthesis' in window)) {
      callback([]);
      return () => {};
    }
    const refresh = () => callback(getSpanishVoices());
    window.speechSynthesis.addEventListener('voiceschanged', refresh);
    refresh();
    return () => window.speechSynthesis.removeEventListener('voiceschanged', refresh);
  }

  function createSpeechQueue({ maxQueued = 40 } = {}) {
    const queue = [];
    let speaking = false;
    let enabled = true;
    let generation = 0;
    let voicePreference = { voiceURI: '', lang: 'es-MX', name: '', volume: 1 };

    function resolveVoice() {
      const voices = getSpanishVoices();
      if (voicePreference.voiceURI) {
        const exactVoice = voices.find((voice) => voice.voiceURI === voicePreference.voiceURI);
        if (exactVoice) return exactVoice;
      }
      const preferredLanguage = (voicePreference.lang || 'es-MX').toLowerCase();
      return voices.find((voice) => voice.lang.toLowerCase() === preferredLanguage)
        || voices.find((voice) => voice.lang.toLowerCase().startsWith(preferredLanguage.split(/[-_]/)[0]))
        || voices[0]
        || null;
    }

    function playNext() {
      if (speaking || queue.length === 0 || !('speechSynthesis' in window)) return;
      const text = queue.shift();
      const utterance = new SpeechSynthesisUtterance(text);
      const utteranceGeneration = generation;
      const voice = resolveVoice();
      utterance.lang = voice?.lang || voicePreference.lang || 'es-MX';
      if (voice) utterance.voice = voice;
      utterance.volume = Math.min(1, Math.max(0, Number(voicePreference.volume ?? 1)));
      utterance.rate = 0.96;
      utterance.pitch = 1;
      utterance.onend = () => {
        if (utteranceGeneration !== generation) return;
        speaking = false;
        playNext();
      };
      utterance.onerror = () => {
        if (utteranceGeneration !== generation) return;
        speaking = false;
        playNext();
      };
      speaking = true;
      window.speechSynthesis.speak(utterance);
    }

    return {
      setVoicePreference(preference) {
        voicePreference = preference && typeof preference === 'object'
          ? { voiceURI: preference.voiceURI || '', lang: preference.lang || 'es-MX', name: preference.name || '', volume: Math.min(1, Math.max(0, Number(preference.volume ?? 1))) }
          : { voiceURI: '', lang: 'es-MX', name: '', volume: 1 };
      },
      speak(text) {
        if (!enabled || !('speechSynthesis' in window)) return false;
        if (queue.length >= maxQueued) queue.shift();
        queue.push(text);
        playNext();
        return true;
      },
      setEnabled(value) {
        enabled = Boolean(value);
        if (!enabled) this.clear();
      },
      clear() {
        generation += 1;
        queue.length = 0;
        if ('speechSynthesis' in window) window.speechSynthesis.cancel();
        speaking = false;
      }
    };
  }

  function logout() {
    token = '';
    sessionStorage.removeItem(ADMIN_TOKEN_KEY);
  }

  window.Ludito = { authenticate, authenticateAdmin, restoreAdminSession, fetchConfig, fetchState, subscribe, submitOrder, toggleRound, resetLiveState, sendChat, saveVoicePreference, getSpanishVoices, onSpanishVoicesChanged, createSpeechQueue, logout };
})();