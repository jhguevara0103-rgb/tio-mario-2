const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = __dirname;
const STATE_FILE = path.resolve(process.env.LUDITO_STATE_FILE || path.join(ROOT, '.ludito-state.json'));
const PORT = Number(process.env.PORT || 5173);
const HOST = process.env.HOST || '0.0.0.0';
const ADMIN_PASSWORD = process.env.LUDITO_ADMIN_PASSWORD || 'tiomario#2026Admin$*';
const COLORS = new Set(['Morado', 'Amarillo', 'Celeste', 'Rojo', 'Verde', 'Naranja']);
const USERS = new Map([
  ['0412', { name: 'Invitado', role: 'client' }],
  ['1234', { name: 'María P.', role: 'client' }]
]);
const sessions = new Map();
const listeners = new Set();
const MIME_TYPES = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml'
};
const PUBLIC_FILES = new Set([
  'index.html', 'admin.html', 'client.css', 'admin.css', 'host-multicolor.css',
  'chat.css', 'voice.css', 'volume-nav.css', 'host-camera.css', 'reset.css', 'shared.js', 'script.js', 'admin.js'
]);

function readInitialState() {
  try {
    const saved = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    if (Array.isArray(saved.events)) {
      return {
        events: saved.events.slice(-250),
        chat: Array.isArray(saved.chat) ? saved.chat.slice(-150) : [],
        voicePreference: saved.voicePreference || null,
        round: Number.isInteger(saved.round) && saved.round > 0 ? saved.round : 1,
        accepting: saved.accepting !== false
      };
    }
  } catch {
    return { events: [], chat: [], voicePreference: null, round: 1, accepting: true };
  }
  return { events: [], chat: [], voicePreference: null, round: 1, accepting: true };
}

let state = readInitialState();

function sendJson(response, status, data) {
  response.writeHead(status, { 'Content-Type': MIME_TYPES['.json'], 'Cache-Control': 'no-store' });
  response.end(JSON.stringify(data));
}

function parseBody(request) {
  return new Promise((resolve, reject) => {
    let body = '';
    request.on('data', (chunk) => {
      body += chunk;
      if (body.length > 16_384) reject(new Error('Request body too large'));
    });
    request.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); } catch { reject(new Error('Invalid JSON')); }
    });
    request.on('error', reject);
  });
}

function currentUser(request) {
  const authorization = request.headers.authorization || '';
  const token = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
  return sessions.get(token);
}

function matchesAdminPassword(candidate) {
  const expectedHash = crypto.createHash('sha256').update(ADMIN_PASSWORD, 'utf8').digest();
  const candidateHash = crypto.createHash('sha256').update(String(candidate || ''), 'utf8').digest();
  return crypto.timingSafeEqual(candidateHash, expectedHash);
}

async function persistAndBroadcast() {
  await fs.promises.writeFile(STATE_FILE, JSON.stringify(state, null, 2));
  const message = `event: state\ndata: ${JSON.stringify(state)}\n\n`;
  for (const response of listeners) response.write(message);
}

function appendEvent(event) {
  state.events.push(event);
  state.events = state.events.slice(-250);
  if (event.type === 'round_closed' && event.round === state.round) state.accepting = false;
  if (event.type === 'round_started' && event.round > state.round) {
    state.round = event.round;
    state.accepting = true;
  }
}

function serveFile(requestPath, response) {
  const route = requestPath === '/' ? '/index.html' : requestPath;
  let decodedRoute;
  try { decodedRoute = decodeURIComponent(route); } catch { sendJson(response, 400, { error: 'Bad path' }); return; }
  const fileName = decodedRoute.replace(/^\/+/, '');
  if (fileName.includes('/') || !PUBLIC_FILES.has(fileName)) {
    sendJson(response, 404, { error: 'Not found' });
    return;
  }
  const filePath = path.join(ROOT, fileName);
  fs.readFile(filePath, (error, contents) => {
    if (error) {
      sendJson(response, 404, { error: 'Not found' });
      return;
    }
    response.writeHead(200, { 'Content-Type': MIME_TYPES[path.extname(filePath)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    response.end(contents);
  });
}

const server = http.createServer(async (request, response) => {
  const url = new URL(request.url, `http://${request.headers.host || 'localhost'}`);
  if (request.method === 'OPTIONS') {
    response.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS' });
    response.end();
    return;
  }

  try {
    if (request.method === 'GET' && url.pathname === '/api/config') {
      sendJson(response, 200, { streamUrl: process.env.LUDITO_STREAM_URL || '', whatsappNumber: process.env.LUDITO_WHATSAPP_NUMBER || '' });
      return;
    }
    if (request.method === 'GET' && url.pathname === '/api/state') {
      sendJson(response, 200, state);
      return;
    }
    if (request.method === 'GET' && url.pathname === '/api/events') {
      response.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
      response.write(`event: snapshot\ndata: ${JSON.stringify(state)}\n\n`);
      listeners.add(response);
      request.on('close', () => listeners.delete(response));
      return;
    }
    if (request.method === 'POST' && url.pathname === '/api/auth') {
      const { pin } = await parseBody(request);
      if (!/^\d{4}$/.test(String(pin || ''))) { sendJson(response, 401, { error: 'El PIN debe tener cuatro dígitos.' }); return; }
      const user = USERS.get(String(pin || ''));
      if (!user) {
        sendJson(response, 401, { error: 'PIN incorrecto.' });
        return;
      }
      if (user.role === 'host') {
        sendJson(response, 403, { error: 'Usa la contraseña de administrador para entrar al panel.' });
        return;
      }
      const token = crypto.randomBytes(24).toString('hex');
      sessions.set(token, user);
      sendJson(response, 200, { token, user: user.name, role: user.role });
      return;
    }
    if (request.method === 'POST' && url.pathname === '/api/admin/auth') {
      const { password } = await parseBody(request);
      if (!matchesAdminPassword(password)) {
        sendJson(response, 401, { error: 'Contraseña incorrecta.' });
        return;
      }
      const user = { name: 'Tío Mario', role: 'host' };
      const token = crypto.randomBytes(32).toString('hex');
      sessions.set(token, user);
      sendJson(response, 200, { token, user: user.name, role: user.role });
      return;
    }
    if (request.method === 'GET' && url.pathname === '/api/admin/session') {
      const user = currentUser(request);
      if (!user || user.role !== 'host') {
        sendJson(response, 401, { error: 'La sesión de administrador no es válida.' });
        return;
      }
      sendJson(response, 200, { user: user.name, role: user.role });
      return;
    }
    if (request.method === 'POST' && url.pathname === '/api/orders') {
      const user = currentUser(request);
      if (!user) { sendJson(response, 401, { error: 'Inicia sesión para enviar un pedido.' }); return; }
      const { items } = await parseBody(request);
      if (!state.accepting) { sendJson(response, 409, { error: 'Los pedidos de esta ronda están cerrados.' }); return; }
      const validItems = Array.isArray(items) && items.length > 0 && items.length <= COLORS.size
        && items.every((item, index) => COLORS.has(item.color)
          && Number.isInteger(item.quantity)
          && item.quantity >= 1
          && item.quantity <= 20
          && items.findIndex((candidate) => candidate.color === item.color) === index);
      if (!validItems) {
        sendJson(response, 400, { error: 'Pedido no válido.' });
        return;
      }
      const normalizedItems = items.map(({ color, quantity }) => ({ color, quantity }));
      const event = { id: crypto.randomUUID(), type: 'order', name: user.name, items: normalizedItems, round: state.round, timestamp: new Date().toISOString() };
      appendEvent(event);
      await persistAndBroadcast();
      sendJson(response, 201, { event, state });
      return;
    }
    if (request.method === 'POST' && url.pathname === '/api/chat') {
      const user = currentUser(request);
      if (!user) { sendJson(response, 401, { error: 'Inicia sesión para enviar mensajes.' }); return; }
      const { message } = await parseBody(request);
      const text = typeof message === 'string' ? message.trim() : '';
      if (!text || text.length > 500) { sendJson(response, 400, { error: 'El mensaje debe tener entre 1 y 500 caracteres.' }); return; }
      const chatMessage = { id: crypto.randomUUID(), name: user.name, text, timestamp: new Date().toISOString() };
      state.chat.push(chatMessage);
      state.chat = state.chat.slice(-150);
      await persistAndBroadcast();
      sendJson(response, 201, { message: chatMessage });
      return;
    }
    if (request.method === 'POST' && url.pathname === '/api/voice') {
      const user = currentUser(request);
      if (!user || user.role !== 'host') { sendJson(response, 403, { error: 'Solo el host puede cambiar la voz.' }); return; }
      const { preference } = await parseBody(request);
      const voiceURI = typeof preference?.voiceURI === 'string' ? preference.voiceURI.slice(0, 500) : '';
      const lang = typeof preference?.lang === 'string' && /^es([_-]|$)/i.test(preference.lang) ? preference.lang.slice(0, 20) : 'es-MX';
      const name = typeof preference?.name === 'string' ? preference.name.slice(0, 120) : 'Voz automática (español)';
      const volume = Number.isFinite(Number(preference?.volume)) ? Math.min(1, Math.max(0, Number(preference.volume))) : 1;
      state.voicePreference = { voiceURI, lang, name, volume };
      await persistAndBroadcast();
      sendJson(response, 200, { voicePreference: state.voicePreference });
      return;
    }
    if (request.method === 'POST' && url.pathname === '/api/rounds/toggle') {
      const user = currentUser(request);
      if (!user || user.role !== 'host') { sendJson(response, 403, { error: 'Solo el host puede controlar las rondas.' }); return; }
      const event = state.accepting
        ? { id: crypto.randomUUID(), type: 'round_closed', round: state.round, timestamp: new Date().toISOString() }
        : { id: crypto.randomUUID(), type: 'round_started', round: state.round + 1, timestamp: new Date().toISOString() };
      appendEvent(event);
      await persistAndBroadcast();
      sendJson(response, 200, { event, state });
      return;
    }
    if (request.method === 'POST' && url.pathname === '/api/admin/reset-live') {
      const user = currentUser(request);
      if (!user || user.role !== 'host') {
        sendJson(response, 403, { error: 'Solo Tío Mario puede reiniciar la transmisión.' });
        return;
      }
      const removedOrders = state.events.filter((event) => event.type === 'order').length;
      const removedChatMessages = state.chat.length;
      state.events = [];
      state.chat = [];
      state.round = 1;
      state.accepting = true;
      await persistAndBroadcast();
      sendJson(response, 200, { state, removedOrders, removedChatMessages });
      return;
    }
    if (request.method === 'POST' && url.pathname === '/api/logout') {
      const authorization = request.headers.authorization || '';
      const token = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
      sessions.delete(token);
      sendJson(response, 200, { ok: true });
      return;
    }
    if (url.pathname.startsWith('/api/')) { sendJson(response, 404, { error: 'API route not found' }); return; }
    if (request.method !== 'GET' && request.method !== 'HEAD') { sendJson(response, 405, { error: 'Method not allowed' }); return; }
    serveFile(url.pathname, response);
  } catch (error) {
    sendJson(response, 400, { error: error.message || 'Request failed' });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Ludito listo en http://localhost:${PORT}`);
  console.log(`En red local: http://<IP-de-este-equipo>:${PORT}`);
});