const hostLogin = document.querySelector('#host-login');
const hostLayout = document.querySelector('#host-layout');
const hostLoginForm = document.querySelector('#host-login-form');
const hostPassword = document.querySelector('#host-password');
const hostLoginError = document.querySelector('#host-login-error');
const hostSession = document.querySelector('#host-session');
const resetButton = document.querySelector('#host-reset-button');
const resetStatus = document.querySelector('#host-reset-status');
const hostRoundStatus = document.querySelector('#host-round-status');
const roundControl = document.querySelector('#host-round-control');
const hostFeed = document.querySelector('#host-feed');
const hostFeedEmpty = document.querySelector('#host-feed-empty');
const orderCount = document.querySelector('#host-order-count');
const hostVideo = document.querySelector('#host-video');
const videoPlaceholder = document.querySelector('#host-video-placeholder');
const streamStatus = document.querySelector('#host-stream-status');
const cameraSelect = document.querySelector('#host-camera-select');
const cameraButton = document.querySelector('#host-camera-button');
const cameraStopButton = document.querySelector('#host-camera-stop');
const cameraNote = document.querySelector('#host-camera-note');
const chatList = document.querySelector('#host-chat-list');
const chatEmpty = document.querySelector('#host-chat-empty');
const chatForm = document.querySelector('#host-chat-form');
const chatInput = document.querySelector('#host-chat-input');
const chatSend = chatForm.querySelector('button');
const chatStatus = document.querySelector('#host-chat-status');
const voiceToggle = document.querySelector('#host-voice-toggle');
const voiceSelector = document.querySelector('#voiceSelector');
const voiceTestButton = document.querySelector('#host-voice-test');
const voiceVolume = document.querySelector('#host-voice-volume');
const voiceVolumeValue = document.querySelector('#host-voice-volume-value');
const speechQueue = window.Ludito.createSpeechQueue();
const seenChatIds = new Set();

let isHost = false;
let spanishVoices = [];
let voicePreference = null;
let localCameraStream = null;
speechQueue.setEnabled(voiceToggle.checked);

function renderVoiceOptions(voices) {
  spanishVoices = voices;
  const selectedVoiceURI = voicePreference?.voiceURI || '';
  voiceSelector.replaceChildren();
  const automaticOption = document.createElement('option');
  automaticOption.value = '';
  automaticOption.textContent = voices.length ? 'Automática (español)' : 'Voz del sistema';
  voiceSelector.append(automaticOption);
  voices.forEach((voice) => {
    const option = document.createElement('option');
    option.value = voice.voiceURI;
    option.textContent = `${voice.name} · ${voice.lang}`;
    voiceSelector.append(option);
  });
  voiceSelector.value = voices.some((voice) => voice.voiceURI === selectedVoiceURI) ? selectedVoiceURI : '';
  voiceSelector.disabled = !isHost;
  voiceTestButton.disabled = !isHost;
  voiceVolume.disabled = !isHost;
}

function colorClass(color) {
  return ({ Morado: 'purple', Amarillo: 'yellow', Celeste: 'sky', Rojo: 'red', Verde: 'green', Naranja: 'orange' })[color] || '';
}

function renderState(state, isLiveUpdate = false) {
  voicePreference = state.voicePreference || null;
  speechQueue.setVoicePreference(voicePreference);
  const volume = Number(voicePreference?.volume ?? 1);
  voiceVolume.value = String(volume);
  voiceVolumeValue.value = `${Math.round(volume * 100)}%`;
  voiceVolumeValue.textContent = `${Math.round(volume * 100)}%`;
  if (spanishVoices.length || voicePreference) renderVoiceOptions(spanishVoices);
  const orders = state.events.filter((event) => event.type === 'order');
  hostFeed.replaceChildren(hostFeedEmpty);
  hostFeedEmpty.hidden = state.events.length > 0;
  orderCount.textContent = `${orders.length} ${orders.length === 1 ? 'pedido' : 'pedidos'}`;
  hostRoundStatus.textContent = `RONDA ${state.round} · PEDIDOS ${state.accepting ? 'ABIERTOS' : 'CERRADOS'}`;
  hostRoundStatus.dataset.open = String(state.accepting);
  roundControl.textContent = state.accepting ? 'Cerrar pedidos' : `Siguiente ronda · ${state.round + 1}`;
  roundControl.dataset.next = String(!state.accepting);
  roundControl.disabled = !isHost;

  state.events.forEach((event) => {
    if (event.type !== 'order') {
      const marker = document.createElement('div');
      marker.className = 'host-round-marker';
      marker.dataset.closed = String(event.type === 'round_closed');
      marker.textContent = event.type === 'round_closed' ? `Pedidos cerrados · Ronda ${event.round}` : `Inicio de Ronda ${event.round}`;
      hostFeed.append(marker);
      return;
    }

    const row = document.createElement('article');
    row.className = 'host-order-row';
    const orderNo = document.createElement('span');
    orderNo.className = 'host-order-number';
    orderNo.textContent = String(orders.indexOf(event) + 1).padStart(2, '0');
    const name = document.createElement('strong');
    name.textContent = event.name;
    const order = document.createElement('span');
    order.className = 'host-order-summary';
    const items = Array.isArray(event.items) ? event.items : [{ color: event.color, quantity: event.quantity }];
    items.forEach((item) => {
      const line = document.createElement('span');
      line.className = 'host-order-item';
      const swatch = document.createElement('i');
      swatch.className = `host-swatch ${colorClass(item.color)}`;
      const text = document.createElement('span');
      text.textContent = `${item.quantity} ${item.color}`;
      line.append(swatch, text);
      order.append(line);
    });
    const time = document.createElement('time');
    time.dateTime = event.timestamp;
    time.textContent = new Intl.DateTimeFormat('es', { hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).format(new Date(event.timestamp));
    const round = document.createElement('span');
    round.className = 'host-order-round';
    round.textContent = `R${event.round}`;
    row.append(orderNo, name, order, time, round);
    hostFeed.append(row);
  });
  hostFeed.scrollTop = hostFeed.scrollHeight;
  renderChat(state.chat || [], isLiveUpdate);
}

function renderChat(messages, isLiveUpdate) {
  chatList.replaceChildren(chatEmpty);
  chatEmpty.hidden = messages.length > 0;
  messages.forEach((message) => {
    if (isLiveUpdate && !seenChatIds.has(message.id) && voiceToggle.checked) {
      speechQueue.speak(`${message.name} dice: ${message.text}`);
    }
    seenChatIds.add(message.id);
    const row = document.createElement('article');
    row.className = 'host-chat-message';
    const header = document.createElement('div');
    header.className = 'host-chat-message-header';
    const name = document.createElement('strong');
    name.textContent = message.name;
    const time = document.createElement('time');
    time.dateTime = message.timestamp;
    time.textContent = new Intl.DateTimeFormat('es', { hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).format(new Date(message.timestamp));
    const text = document.createElement('p');
    text.textContent = message.text;
    header.append(name, time);
    row.append(header, text);
    chatList.append(row);
  });
  chatList.scrollTop = chatList.scrollHeight;
}

async function unlockHost(session) {
  if (!session || session.role !== 'host') throw new Error('Esta cuenta no tiene permisos de host.');
  isHost = true;
  hostSession.textContent = session.user.toUpperCase();
  hostLogin.hidden = true;
  hostLayout.hidden = false;
  hostPassword.value = '';
  resetButton.disabled = false;
  roundControl.disabled = false;
  renderVoiceOptions(spanishVoices);
  chatInput.disabled = false;
  chatSend.disabled = false;
  chatStatus.textContent = 'Conectado al chat';
  renderState(await window.Ludito.fetchState());
  await refreshCameras();
}

async function refreshCameras() {
  if (!navigator.mediaDevices?.enumerateDevices) {
    cameraNote.textContent = 'Este navegador no permite acceder a cámaras locales.';
    cameraButton.disabled = true;
    return;
  }

  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const cameras = devices.filter((device) => device.kind === 'videoinput');
    const selectedId = cameraSelect.value;
    cameraSelect.replaceChildren();
    cameras.forEach((camera, index) => {
      const option = document.createElement('option');
      option.value = camera.deviceId;
      option.textContent = camera.label || `Cámara ${index + 1}`;
      cameraSelect.append(option);
    });
    if (selectedId && cameras.some((camera) => camera.deviceId === selectedId)) cameraSelect.value = selectedId;
    cameraSelect.disabled = cameras.length === 0;
    cameraButton.disabled = cameras.length === 0 || Boolean(localCameraStream);
    if (!cameras.length) cameraNote.textContent = 'No se detectan cámaras. Activa OBS Virtual Camera y vuelve a intentarlo.';
    else cameraNote.textContent = 'Selecciona OBS Virtual Camera para previsualizar la señal local.';
  } catch {
    cameraNote.textContent = 'No se pudo consultar la lista de cámaras.';
  }
}

async function connectLocalCamera() {
  if (!isHost || !navigator.mediaDevices?.getUserMedia) return;
  cameraButton.disabled = true;
  cameraNote.textContent = 'Solicitando acceso a la cámara…';
  try {
    const deviceId = cameraSelect.value;
    const video = deviceId ? { deviceId: { exact: deviceId } } : true;
    const stream = await navigator.mediaDevices.getUserMedia({ video, audio: false });
    if (localCameraStream) localCameraStream.getTracks().forEach((track) => track.stop());
    localCameraStream = stream;
    hostVideo.srcObject = stream;
    hostVideo.muted = true;
    hostVideo.playsInline = true;
    await hostVideo.play();
    const activeDeviceId = stream.getVideoTracks()[0]?.getSettings().deviceId;
    if (activeDeviceId) cameraSelect.value = activeDeviceId;
    videoPlaceholder.hidden = true;
    streamStatus.textContent = 'Cámara local conectada';
    cameraNote.textContent = 'Previsualización local activa. Para los clientes, publica el stream desde OBS.';
    cameraSelect.disabled = true;
    cameraButton.hidden = true;
    cameraStopButton.hidden = false;
    await refreshCameras();
  } catch (error) {
    cameraButton.disabled = false;
    cameraNote.textContent = error.name === 'NotAllowedError'
      ? 'Permite el acceso a la cámara en el navegador.'
      : 'No se pudo conectar. Comprueba que OBS Virtual Camera esté activa.';
  }
}

function disconnectLocalCamera() {
  if (localCameraStream) localCameraStream.getTracks().forEach((track) => track.stop());
  localCameraStream = null;
  hostVideo.srcObject = null;
  videoPlaceholder.hidden = false;
  streamStatus.textContent = 'Sin señal configurada';
  cameraButton.hidden = false;
  cameraStopButton.hidden = true;
  refreshCameras();
}

cameraButton.addEventListener('click', connectLocalCamera);
cameraStopButton.addEventListener('click', disconnectLocalCamera);
cameraSelect.addEventListener('change', () => {
  if (localCameraStream) connectLocalCamera();
  else cameraButton.disabled = !cameraSelect.value;
});

hostLoginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  hostLoginError.textContent = '';
  try {
    await unlockHost(await window.Ludito.authenticateAdmin(hostPassword.value));
  } catch (error) {
    hostLoginError.textContent = error.message;
    hostPassword.setAttribute('aria-invalid', 'true');
    hostPassword.focus();
  }
});

resetButton.addEventListener('click', async () => {
  if (!isHost || resetButton.disabled) return;
  const confirmed = window.confirm('Se borrarán todos los pedidos, mensajes de chat y separadores de ronda. La transmisión volverá a la ronda 1 con pedidos abiertos. La sesión de Tío Mario y la voz elegida se conservarán. ¿Continuar?');
  if (!confirmed) return;

  resetButton.disabled = true;
  resetStatus.textContent = 'Reiniciando la transmisión…';
  speechQueue.clear();
  seenChatIds.clear();
  try {
    const result = await window.Ludito.resetLiveState();
    renderState(result.state);
    resetStatus.textContent = `Listo: ${result.removedOrders} pedidos y ${result.removedChatMessages} mensajes eliminados. Ronda 1 abierta.`;
  } catch (error) {
    resetStatus.textContent = error.message;
  } finally {
    resetButton.disabled = !isHost;
  }
});

window.Ludito.restoreAdminSession().then((session) => {
  if (!session || isHost) return;
  unlockHost(session).catch((error) => {
    window.Ludito.logout();
    hostLogin.hidden = false;
    hostLoginError.textContent = error.message;
  });
});

voiceSelector.addEventListener('change', async () => {
  if (!isHost) return;
  const voice = spanishVoices.find((candidate) => candidate.voiceURI === voiceSelector.value);
  const preference = voice
    ? { voiceURI: voice.voiceURI, lang: voice.lang, name: voice.name, volume: Number(voiceVolume.value) }
    : { voiceURI: '', lang: 'es-MX', name: 'Automática (español)', volume: Number(voiceVolume.value) };
  voicePreference = preference;
  speechQueue.setVoicePreference(preference);
  voiceSelector.disabled = true;
  try {
    await window.Ludito.saveVoicePreference(preference);
    streamStatus.textContent = `Voz seleccionada: ${preference.name}`;
  } catch (error) {
    streamStatus.textContent = error.message;
  } finally {
    voiceSelector.disabled = !isHost;
  }
});

let voiceSaveTimer = null;
voiceVolume.addEventListener('input', () => {
  const volume = Number(voiceVolume.value);
  voiceVolumeValue.value = `${Math.round(volume * 100)}%`;
  voiceVolumeValue.textContent = `${Math.round(volume * 100)}%`;
  voicePreference = { ...(voicePreference || {}), voiceURI: voicePreference?.voiceURI || '', lang: voicePreference?.lang || 'es-MX', name: voicePreference?.name || 'Automática (español)', volume };
  speechQueue.setVoicePreference(voicePreference);
  window.clearTimeout(voiceSaveTimer);
  voiceSaveTimer = window.setTimeout(async () => {
    try {
      await window.Ludito.saveVoicePreference(voicePreference);
    } catch (error) {
      streamStatus.textContent = error.message;
    }
  }, 180);
});

voiceTestButton.addEventListener('click', () => {
  speechQueue.speak('Hola. Esta es una prueba de la voz del chat en español.');
});

voiceToggle.addEventListener('change', () => {
  speechQueue.setEnabled(voiceToggle.checked);
});

window.Ludito.onSpanishVoicesChanged((voices) => {
  renderVoiceOptions(voices);
});

chatForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const message = chatInput.value.trim();
  if (!isHost || !message) return;
  chatInput.disabled = true;
  chatSend.disabled = true;
  try {
    await window.Ludito.sendChat(message);
    chatInput.value = '';
    chatStatus.textContent = 'Mensaje enviado.';
  } catch (error) {
    chatStatus.textContent = error.message;
  } finally {
    chatInput.disabled = !isHost;
    chatSend.disabled = !isHost;
    if (isHost) chatInput.focus();
  }
});

roundControl.addEventListener('click', async () => {
  if (!isHost || roundControl.disabled) return;
  roundControl.disabled = true;
  try {
    await window.Ludito.toggleRound();
  } catch (error) {
    streamStatus.textContent = error.message;
  } finally {
    roundControl.disabled = !isHost;
  }
});

window.Ludito.subscribe(renderState, (connected) => {
  document.querySelector('.host-live').dataset.connected = String(connected);
});
window.Ludito.fetchState().then(renderState).catch(() => { streamStatus.textContent = 'Servidor no disponible'; });
window.Ludito.fetchConfig().then((config) => {
  if (!config.streamUrl) return;
  hostVideo.src = config.streamUrl;
  hostVideo.addEventListener('playing', () => {
    videoPlaceholder.hidden = true;
    streamStatus.textContent = 'Señal conectada';
  });
  hostVideo.addEventListener('error', () => { streamStatus.textContent = 'No se pudo abrir la señal'; });
}).catch(() => { streamStatus.textContent = 'Servidor no disponible'; });

window.addEventListener('pagehide', () => {
  if (localCameraStream) localCameraStream.getTracks().forEach((track) => track.stop());
});
