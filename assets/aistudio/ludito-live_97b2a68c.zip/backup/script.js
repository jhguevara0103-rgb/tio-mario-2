const previewOverlay = document.querySelector('#preview-overlay');
const previewCountdown = document.querySelector('#preview-countdown');
const screensaverScreen = document.querySelector('#screensaver-screen');
const screensaverClose = document.querySelector('#screensaver-close');
const accessScreen = document.querySelector('#access-screen');
const accessButton = document.querySelector('#pin-access-button');
const accessClose = document.querySelector('#access-close');
const loginForm = document.querySelector('#login-form');
const pinInput = document.querySelector('#pin-input');
const loginMessage = document.querySelector('#login-message');
const whatsappLink = document.querySelector('#whatsapp-link');
const clientVideo = document.querySelector('#client-video');
const audioEnableButton = document.querySelector('#audio-enable-button');
const streamPlaceholder = document.querySelector('#stream-placeholder');
const streamStatus = document.querySelector('#stream-status');
const clientOrder = document.querySelector('#client-order');
const userLabel = document.querySelector('#user-label');
const submitButton = document.querySelector('#submit-order');
const orderMessage = document.querySelector('#order-message');
const clientClosed = document.querySelector('#client-closed');
const roundLabel = document.querySelector('#client-round');
const feedList = document.querySelector('#feed-list');
const feedEmpty = document.querySelector('#feed-empty');
const feedCount = document.querySelector('#feed-count');
const colorRows = [...document.querySelectorAll('.client-color-row')];
const selectionTotal = document.querySelector('#selection-total');
const chatList = document.querySelector('#client-chat-list');
const chatEmpty = document.querySelector('#client-chat-empty');
const chatForm = document.querySelector('#client-chat-form');
const chatInput = document.querySelector('#client-chat-input');
const chatSend = document.querySelector('#client-chat-send');
const chatStatus = document.querySelector('#client-chat-status');
const voiceToggle = document.querySelector('#client-voice-toggle');
const voiceVolume = document.querySelector('#client-voice-volume');
const voiceVolumeValue = document.querySelector('#client-voice-volume-value');
const speechQueue = window.Ludito.createSpeechQueue();
const seenChatIds = new Set();
speechQueue.setEnabled(voiceToggle.checked);

const PIN_USERS = Object.freeze({
  '0412': 'Invitado',
  '1234': 'María P.'
});

const selectedQuantities = new Map(colorRows.map((row) => [row.dataset.color, 0]));
let acceptingOrders = true;
let authenticated = false;
let activeUserName = '';
let currentState = { events: [], round: 1, accepting: true };
let voicePreference = null;
let localVoiceVolume = Number(localStorage.getItem('ludito-client-voice-volume') ?? 1);
localVoiceVolume = Math.min(1, Math.max(0, Number.isFinite(localVoiceVolume) ? localVoiceVolume : 1));
const previewDeadline = 15000;
let previewExpired = false;
let screensaverDismissed = false;

function colorClass(color) {
  return ({ Morado: 'purple', Amarillo: 'yellow', Celeste: 'sky', Rojo: 'red', Verde: 'green', Naranja: 'orange' })[color] || '';
}

function renderState(state, isLiveUpdate = false) {
  currentState = state;
  voicePreference = state.voicePreference || null;
  speechQueue.setVoicePreference({ ...voicePreference, volume: localVoiceVolume });
  const orders = state.events.filter((event) => event.type === 'order');
  feedList.replaceChildren(feedEmpty);
  feedEmpty.hidden = state.events.length > 0;
  feedCount.textContent = `${orders.length} ${orders.length === 1 ? 'pedido' : 'pedidos'}`;
  roundLabel.textContent = `RONDA ${state.round}`;
  acceptingOrders = state.accepting;
  clientClosed.hidden = acceptingOrders;

  state.events.forEach((event) => {
    if (event.type !== 'order') {
      const marker = document.createElement('div');
      marker.className = 'client-round-marker';
      marker.dataset.closed = String(event.type === 'round_closed');
      marker.textContent = event.type === 'round_closed' ? `Pedidos cerrados · Ronda ${event.round}` : `Inicio de Ronda ${event.round}`;
      feedList.append(marker);
      return;
    }

    const row = document.createElement('div');
    row.className = 'client-feed-row';
    const name = document.createElement('strong');
    name.textContent = event.name;
    const summary = document.createElement('span');
    summary.className = 'client-feed-summary';
    const orderText = document.createElement('span');
    const items = Array.isArray(event.items) ? event.items : [{ color: event.color, quantity: event.quantity }];
    orderText.textContent = `pidió ${items.map((item) => `${item.quantity} ${item.color}`).join(' · ')}`;
    summary.append(orderText);
    const time = document.createElement('time');
    time.dateTime = event.timestamp;
    time.textContent = new Intl.DateTimeFormat('es', { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date(event.timestamp));
    row.append(name, summary, time);
    feedList.append(row);
  });
  feedList.scrollTop = feedList.scrollHeight;
  renderChat(state.chat || [], isLiveUpdate);
  updateOrderControls();
}

function renderChat(messages, isLiveUpdate) {
  chatList.replaceChildren(chatEmpty);
  chatEmpty.hidden = messages.length > 0;
  messages.forEach((message) => {
    if (isLiveUpdate && !seenChatIds.has(message.id) && voiceToggle.checked) {
      speechQueue.speak(`${message.name} dice: ${message.text}`);
    }
    seenChatIds.add(message.id);
    const row = document.createElement('article');
    row.className = 'client-chat-message';
    const header = document.createElement('div');
    header.className = 'client-chat-message-header';
    const name = document.createElement('strong');
    name.textContent = message.name;
    const time = document.createElement('time');
    time.dateTime = message.timestamp;
    time.textContent = new Intl.DateTimeFormat('es', { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date(message.timestamp));
    const text = document.createElement('p');
    text.textContent = message.text;
    header.append(name, time);
    row.append(header, text);
    chatList.append(row);
  });
  chatList.scrollTop = chatList.scrollHeight;
}

function updateOrderControls() {
  let totalQuantity = 0;
  colorRows.forEach((row) => {
    const color = row.dataset.color;
    const amount = selectedQuantities.get(color) || 0;
    totalQuantity += amount;
    row.querySelector('output').textContent = String(amount);
    row.dataset.selected = String(amount > 0);
    row.querySelectorAll('button').forEach((button) => {
      const step = Number(button.dataset.step);
      button.disabled = !acceptingOrders || (step < 0 ? amount === 0 : amount >= 20);
    });
  });
  selectionTotal.textContent = `${totalQuantity} ${totalQuantity === 1 ? 'cupo seleccionado' : 'cupos seleccionados'}`;
  submitButton.disabled = !authenticated || totalQuantity === 0 || !acceptingOrders;
}

function unlockClient(user) {
  authenticated = true;
  activeUserName = user;
  sessionStorage.setItem('ludito-client-user', user);
  accessScreen.hidden = true;
  screensaverScreen.hidden = true;
  previewOverlay.hidden = true;
  clientOrder.hidden = false;
  userLabel.textContent = user.toUpperCase();
  chatInput.disabled = false;
  chatSend.disabled = false;
  chatStatus.textContent = 'Conectado al chat';
  pinInput.value = '';
  updateOrderControls();
}

function dismissScreensaver() {
  screensaverDismissed = true;
  screensaverScreen.hidden = true;
  document.body.dataset.mode = 'spectator';
}

function openPinAccess() {
  if (authenticated) return;
  screensaverScreen.hidden = true;
  previewOverlay.hidden = true;
  accessScreen.hidden = false;
  document.body.dataset.mode = 'pin-access';
  pinInput.focus({ preventScroll: true });
}

function closePinAccess() {
  accessScreen.hidden = true;
  if (!authenticated && previewExpired && !screensaverDismissed) screensaverScreen.hidden = false;
  else if (!authenticated && !previewExpired) previewOverlay.hidden = false;
  if (!authenticated && screensaverDismissed) document.body.dataset.mode = 'spectator';
}

screensaverClose.addEventListener('click', dismissScreensaver);
screensaverScreen.addEventListener('click', (event) => {
  if (event.target === screensaverScreen) dismissScreensaver();
});

accessButton.addEventListener('click', openPinAccess);
accessClose.addEventListener('click', closePinAccess);
accessScreen.addEventListener('click', (event) => {
  if (event.target === accessScreen) closePinAccess();
});

function updatePreviewTimer() {
  const remaining = Math.max(0, previewDeadline - performance.now());
  previewCountdown.textContent = String(Math.ceil(remaining / 1000));
  if (remaining > 0) return;

  previewExpired = true;
  previewOverlay.hidden = true;
  if (!authenticated && !screensaverDismissed && accessScreen.hidden) screensaverScreen.hidden = false;
  window.clearInterval(previewTimer);
}

const previewTimer = window.setInterval(updatePreviewTimer, 100);
updatePreviewTimer();

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  loginMessage.textContent = '';
  const pin = pinInput.value.trim();
  if (!/^\d{4}$/.test(pin) || !PIN_USERS[pin]) {
    loginMessage.textContent = 'PIN no registrado. Verifica los cuatro dígitos.';
    pinInput.setAttribute('aria-invalid', 'true');
    pinInput.focus();
    return;
  }
  try {
    const session = await window.Ludito.authenticate(pin);
    if (session.role !== 'client') {
      window.Ludito.logout();
      throw new Error('Usa el acceso de cliente para enviar pedidos.');
    }
    if (session.user !== PIN_USERS[pin]) throw new Error('El usuario del PIN no coincide con el registro.');
    unlockClient(session.user);
  } catch (error) {
    loginMessage.textContent = error.message;
    pinInput.setAttribute('aria-invalid', 'true');
    pinInput.focus();
  }
});

pinInput.addEventListener('input', () => {
  loginMessage.textContent = '';
  pinInput.removeAttribute('aria-invalid');
});

colorRows.forEach((row) => {
  row.querySelectorAll('button').forEach((button) => {
    button.addEventListener('click', () => {
      const color = row.dataset.color;
      const nextValue = (selectedQuantities.get(color) || 0) + Number(button.dataset.step);
      selectedQuantities.set(color, Math.max(0, Math.min(20, nextValue)));
      orderMessage.textContent = '';
      updateOrderControls();
    });
  });
});

submitButton.addEventListener('click', async () => {
  if (submitButton.disabled) return;
  submitButton.disabled = true;
  try {
    const items = [...selectedQuantities]
      .filter(([, amount]) => amount > 0)
      .map(([color, amount]) => ({ color, quantity: amount }));
    await window.Ludito.submitOrder(items);
    orderMessage.textContent = 'Pedido registrado.';
    selectedQuantities.forEach((_, color) => selectedQuantities.set(color, 0));
  } catch (error) {
    orderMessage.textContent = error.message;
  } finally {
    updateOrderControls();
  }
});

chatForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const message = chatInput.value.trim();
  if (!authenticated || !message) return;
  chatInput.disabled = true;
  chatSend.disabled = true;
  try {
    await window.Ludito.sendChat(message);
    chatInput.value = '';
    chatStatus.textContent = 'Mensaje enviado.';
  } catch (error) {
    chatStatus.textContent = error.message;
  } finally {
    chatInput.disabled = !authenticated;
    chatSend.disabled = !authenticated;
    if (authenticated) chatInput.focus();
  }
});

window.Ludito.subscribe(renderState, (connected) => {
  if (!connected) streamStatus.textContent = 'Reconectando al registro';
});

window.Ludito.onSpanishVoicesChanged(() => {});

voiceToggle.addEventListener('change', () => {
  speechQueue.setEnabled(voiceToggle.checked);
});

function renderClientVolume() {
  voiceVolume.value = String(localVoiceVolume);
  voiceVolumeValue.value = `${Math.round(localVoiceVolume * 100)}%`;
  voiceVolumeValue.textContent = `${Math.round(localVoiceVolume * 100)}%`;
}

voiceVolume.addEventListener('input', () => {
  localVoiceVolume = Number(voiceVolume.value);
  localStorage.setItem('ludito-client-voice-volume', String(localVoiceVolume));
  speechQueue.setVoicePreference({ ...voicePreference, volume: localVoiceVolume });
  renderClientVolume();
});

renderClientVolume();

Promise.all([window.Ludito.fetchConfig(), window.Ludito.fetchState()]).then(([config, state]) => {
  if (config.streamUrl) {
    clientVideo.src = config.streamUrl;
    clientVideo.addEventListener('playing', () => {
      streamPlaceholder.hidden = true;
      streamStatus.textContent = 'Señal conectada';
    });
    clientVideo.addEventListener('error', () => { streamStatus.textContent = 'No se pudo abrir la señal'; });
  } else {
    streamStatus.textContent = 'Esperando señal en vivo';
  }
  if (config.whatsappNumber) whatsappLink.href = `https://wa.me/${config.whatsappNumber}?text=Hola%2C%20quiero%20solicitar%20un%20PIN%20para%20Ludito.`;
  renderState(state);
}).catch(() => { streamStatus.textContent = 'Conecta con el servidor para participar'; });

clientVideo.addEventListener('playing', () => {
  streamPlaceholder.hidden = true;
  streamStatus.textContent = 'Señal conectada';
});

clientVideo.addEventListener('error', () => {
  streamStatus.textContent = 'No se pudo abrir la señal';
});

audioEnableButton.addEventListener('click', async () => {
  clientVideo.muted = false;
  try {
    await clientVideo.play();
    audioEnableButton.hidden = true;
  } catch {
    clientVideo.muted = true;
    streamStatus.textContent = 'Toca de nuevo para activar el audio';
  }
});

clientVideo.addEventListener('volumechange', () => {
  if (!clientVideo.muted) audioEnableButton.hidden = true;
});

clientVideo.addEventListener('loadeddata', async () => {
  try {
    await clientVideo.play();
    streamPlaceholder.hidden = true;
    streamStatus.textContent = 'Señal conectada';
  } catch {
    audioEnableButton.hidden = false;
    streamStatus.textContent = 'La reproducción automática con audio fue bloqueada';
  }
});
