# Ludito Live

Aplicacion web ligera con vista vertical de participante y panel horizontal de host. No requiere paquetes npm; usa Node.js integrado.

## Iniciar

Desde esta carpeta:

```powershell
node server.js
```

Abre `http://localhost:5173/` para participantes y `http://localhost:5173/admin.html` para el host. Para que otros dispositivos en la misma red entren, usa la IP local del equipo que ejecuta el servidor, por ejemplo `http://192.168.1.20:5173/`. Permite el puerto en el firewall local si Windows lo solicita.

## Configuracion

PIN de demostracion:

- `0412`: participante Invitado
- `1234`: participante María P.

El panel `/admin.html` solicita la contraseña exclusiva del host y la valida en el servidor. La sesión se conserva en `sessionStorage` de esa pestaña y se vuelve a verificar al recargar; al cerrar la pestaña, se elimina. La identidad host es Tío Mario; el PIN `0535` no concede acceso host. Para instalaciones persistentes, establece `LUDITO_ADMIN_PASSWORD` antes de iniciar Node y no distribuyas esa clave en el cliente. La contraseña configurada para pruebas debe cambiarse antes de publicar el servicio.

Tras iniciar sesión, el panel de host permite seleccionar una cámara local y previsualizar OBS Virtual Camera. Esa conexión es una vista previa local del host; los clientes móviles reciben el stream configurado en `LUDITO_STREAM_URL`, no la cámara USB capturada localmente.

Cada participante puede asignar cantidades independientes a varios colores y enviarlos juntos como un único pedido. El nombre se toma del PIN validado por el servidor y no se solicita manualmente.

Configura el telefono de WhatsApp del organizador (solo digitos, con codigo de pais) y la URL de un stream reproducible por el navegador con variables de entorno antes de iniciar el servidor:

```powershell
$env:LUDITO_WHATSAPP_NUMBER = '5215512345678'
$env:LUDITO_STREAM_URL = 'https://servidor.example/live.m3u8'
$env:LUDITO_ADMIN_PASSWORD = 'una-clave-larga-y-unica'
node server.js
```

El formato del stream debe ser compatible con `<video>` en el navegador. Una URL HLS `.m3u8` funciona de forma nativa principalmente en Safari; para otros navegadores publica una salida WebRTC compatible o una URL de formato soportado por el navegador. Una camara virtual de OBS local no se convierte automaticamente en stream para los telefonos: OBS debe emitir a un servidor/plataforma y se configura aqui la URL de reproduccion.

El botón de administración `Limpiar Chat y Reiniciar Sesión` requiere una confirmación y borra todos los mensajes, pedidos y marcadores de ronda, dejando ronda 1 abierta. Mantiene la sesión del host y la preferencia de voz.

## Almacenamiento y alcance

El servidor guarda rondas y pedidos en `.ludito-state.json` en esta carpeta y distribuye cambios al instante usando Server-Sent Events. No borres ese archivo si quieres conservar el historial. Los PIN de demostracion y las sesiones en memoria son para pruebas; antes de exponerlo a Internet, sustituye la autenticacion, usa HTTPS y agrega controles de persistencia y operacion adecuados.

## Chat y voz

El chat aparece en la vista de participante y en el panel de host. Participantes autenticados por PIN y el host autenticado por contraseña pueden publicar; los mensajes se muestran en ambas vistas por Server-Sent Events y se conservan en el estado del servidor. El host lee mensajes nuevos en voz alta por defecto; en cliente, la casilla `Leer mensajes` permite activar esa lectura. Al desmarcar `Voz activa`, el host cancela el habla actual y limpia la cola. El selector `Voz` del host lista las voces españolas que ofrece el navegador, permite probar una muestra y guarda la preferencia en el estado compartido. Cada dispositivo intenta usar la URI seleccionada y, si no tiene esa voz instalada, usa una voz local del mismo idioma. El TTS usa una cola serial para evitar solapamientos; el historial no se vuelve a leer al abrir una vista.
