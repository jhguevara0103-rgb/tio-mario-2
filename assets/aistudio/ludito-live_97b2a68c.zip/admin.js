const hostLogin = document.querySelector('#host-login');
const hostLayout = document.querySelector('#host-layout');
const hostLoginForm = document.querySelector('#host-login-form');
const hostPassword = document.querySelector('#host-password');
const hostLoginError = document.querySelector('#host-login-error');
const hostSession = document.querySelector('#host-session');
const resetButton = document.querySelector('#host-reset-button');
const resetStatus = document.querySelector('#host-reset-status');
const resetModal = document.querySelector('#reset-confirm-modal');
const resetCancel = document.querySelector('#reset-modal-cancel');
const resetConfirm = document.querySelector('#reset-modal-confirm');
const resetChatOnly = document.querySelector('#reset-modal-chatonly');
const hostRoundStatus = document.querySelector('#host-round-status');
const roundControl = document.querySelector('#host-round-control');
const hostFeed = document.querySelector('#host-feed');
const hostFeedEmpty = document.querySelector('#host-feed-empty');
const orderCount = document.querySelector('#host-order-count');
const hostVideo = document.querySelector('#host-video');
const videoPlaceholder = document.querySelector('#host-video-placeholder');
const streamStatus = document.querySelector('#host-stream-status');
const cameraSelect = document.querySelector('#host-camera-select');
const cameraButton = document.querySelector('#host-camera-button');
const cameraStopButton = document.querySelector('#host-camera-stop');
const cameraNote = document.querySelector('#host-camera-note');
const hostAudioButton = document.querySelector('#host-audio-button');
const hostAudioIcon = document.querySelector('#host-audio-icon');
const hostAudioLabel = document.querySelector('#host-audio-label');
const capacityForm = document.querySelector('#host-capacity-form');
const capacityInput = document.querySelector('#host-capacity-input');
const capacityBadge = document.querySelector('#host-capacity-current-badge');
const capacitySummary = document.querySelector('#host-capacity-summary');
const capacityStatus = document.querySelector('#host-capacity-status');
const capacityClearBtn = document.querySelector('#host-capacity-clear');
const capacitySubmitBtn = document.querySelector('#host-capacity-submit');
const capacityPresetBtns = [...document.querySelectorAll('.preset-btn')];
const chatList = document.querySelector('#host-chat-list');
const chatEmpty = document.querySelector('#host-chat-empty');
const chatForm = document.querySelector('#host-chat-form');
const chatInput = document.querySelector('#host-chat-input');
const chatSend = chatForm.querySelector('button');
const chatStatus = document.querySelector('#host-chat-status');
const voiceToggle = document.querySelector('#host-voice-toggle');
const voiceSelector = document.querySelector('#voiceSelector');
const voiceTestButton = document.querySelector('#host-voice-test');
const voiceVolume = document.querySelector('#host-voice-volume');
const voiceVolumeValue = document.querySelector('#host-voice-volume-value');
const speechQueue = window.Ludito.createSpeechQueue();
const seenChatIds = new Set();

let isHost = false;
let spanishVoices = [];
let voicePreference = null;
let localCameraStream = null;
speechQueue.setEnabled(voiceToggle.checked);

function renderVoiceOptions(voices) {
  spanishVoices = voices;
  const selectedVoiceURI = voicePreference?.voiceURI || '';
  voiceSelector.replaceChildren();
  const automaticOption = document.createElement('option');
  automaticOption.value = '';
  automaticOption.textContent = voices.length ? 'Automática (español)' : 'Voz del sistema';
  voiceSelector.append(automaticOption);
  voices.forEach((voice) => {
    const option = document.createElement('option');
    option.value = voice.voiceURI;
    option.textContent = `${voice.name} · ${voice.lang}`;
    voiceSelector.append(option);
  });
  voiceSelector.value = voices.some((voice) => voice.voiceURI === selectedVoiceURI) ? selectedVoiceURI : '';
  voiceSelector.disabled = !isHost;
  voiceTestButton.disabled = !isHost;
  voiceVolume.disabled = !isHost;
}

function colorClass(color) {
  return ({ Morado: 'purple', Amarillo: 'yellow', Celeste: 'sky', Rojo: 'red', Verde: 'green', Naranja: 'orange' })[color] || '';
}

function renderState(state, isLiveUpdate = false) {
  if (!state.chat || state.chat.length === 0) {
    seenChatIds.clear();
    speechQueue.clear();
  }
  voicePreference = state.voicePreference || null;
  speechQueue.setVoicePreference(voicePreference);
  const volume = Number(voicePreference?.volume ?? 1);
  voiceVolume.value = String(volume);
  voiceVolumeValue.value = `${Math.round(volume * 100)}%`;
  voiceVolumeValue.textContent = `${Math.round(volume * 100)}%`;
  if (spanishVoices.length || voicePreference) renderVoiceOptions(spanishVoices);
  const orders = state.events.filter((event) => event.type === 'order');
  hostFeed.replaceChildren(hostFeedEmpty);
  hostFeedEmpty.hidden = state.events.length > 0;
  orderCount.textContent = `${orders.length} ${orders.length === 1 ? 'pedido' : 'pedidos'}`;
  hostRoundStatus.textContent = `RONDA ${state.round} · PEDIDOS ${state.accepting ? 'ABIERTOS' : 'CERRADOS'}`;
  hostRoundStatus.dataset.open = String(state.accepting);
  roundControl.textContent = state.accepting ? 'Cerrar pedidos' : `Siguiente ronda · ${state.round + 1}`;
  roundControl.dataset.next = String(!state.accepting);
  roundControl.disabled = !isHost;

  // Round capacity per color rendering
  const COLORS_LIST = ['Rojo', 'Morado', 'Amarillo', 'Celeste', 'Naranja', 'Verde'];
  const roundOrders = state.events.filter((e) => e.type === 'order' && e.round === state.round);
  const colorCounts = new Map(COLORS_LIST.map((c) => [c, 0]));
  roundOrders.forEach((e) => {
    const items = Array.isArray(e.items) ? e.items : [{ color: e.color, quantity: e.quantity }];
    items.forEach((item) => {
      if (colorCounts.has(item.color)) {
        colorCounts.set(item.color, colorCounts.get(item.color) + (item.quantity || 1));
      }
    });
  });

  if (state.roundCapacity != null && state.roundCapacity > 0) {
    capacityBadge.textContent = `${state.roundCapacity} por color`;
    capacityBadge.classList.add('active');
    if (document.activeElement !== capacityInput) {
      capacityInput.value = String(state.roundCapacity);
    }

    capacitySummary.replaceChildren();
    const grid = document.createElement('div');
    grid.className = 'host-capacity-grid';

    COLORS_LIST.forEach((color) => {
      const taken = colorCounts.get(color) || 0;
      const remaining = Math.max(0, state.roundCapacity - taken);
      const item = document.createElement('div');
      item.className = 'host-capacity-item';
      item.dataset.soldOut = String(remaining === 0);

      const dot = document.createElement('i');
      dot.className = `host-swatch ${colorClass(color)}`;

      const label = document.createElement('span');
      label.className = 'host-capacity-item-name';
      label.textContent = color;

      const count = document.createElement('strong');
      count.className = 'host-capacity-item-count';
      count.textContent = remaining === 0 ? 'AGOTADO' : `${remaining} libres`;

      const total = document.createElement('small');
      total.textContent = `(${taken}/${state.roundCapacity})`;

      item.append(dot, label, count, total);
      grid.append(item);
    });
    capacitySummary.append(grid);
  } else {
    capacityBadge.textContent = 'Sin límite (Libre)';
    capacityBadge.classList.remove('active');
    if (document.activeElement !== capacityInput) {
      capacityInput.value = '';
    }
    capacitySummary.innerHTML = '<p class="host-capacity-unlimited-note">Modo libre: Los clientes pueden pedir sin tope hasta que fijes los espacios.</p>';
  }

  state.events.forEach((event) => {
    if (event.type !== 'order') {
      const marker = document.createElement('div');
      marker.className = 'host-round-marker';
      marker.dataset.closed = String(event.type === 'round_closed');
      marker.textContent = event.type === 'round_closed' ? `Pedidos cerrados · Ronda ${event.round}` : `Inicio de Ronda ${event.round}`;
      hostFeed.append(marker);
      return;
    }

    const row = document.createElement('article');
    row.className = 'host-order-row';
    const orderNo = document.createElement('span');
    orderNo.className = 'host-order-number';
    orderNo.textContent = String(orders.indexOf(event) + 1).padStart(2, '0');
    const name = document.createElement('strong');
    name.textContent = event.name;
    const order = document.createElement('span');
    order.className = 'host-order-summary';
    const items = Array.isArray(event.items) ? event.items : [{ color: event.color, quantity: event.quantity }];
    items.forEach((item) => {
      const line = document.createElement('span');
      line.className = 'host-order-item';
      const swatch = document.createElement('i');
      swatch.className = `host-swatch ${colorClass(item.color)}`;
      const text = document.createElement('span');
      text.textContent = `${item.quantity} ${item.color}`;
      line.append(swatch, text);
      order.append(line);
    });
    const time = document.createElement('time');
    time.dateTime = event.timestamp;
    time.textContent = new Intl.DateTimeFormat('es', { hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).format(new Date(event.timestamp));
    const round = document.createElement('span');
    round.className = 'host-order-round';
    round.textContent = `R${event.round}`;
    row.append(orderNo, name, order, time, round);
    hostFeed.append(row);
  });
  hostFeed.scrollTop = hostFeed.scrollHeight;
  renderChat(state.chat || [], isLiveUpdate);
}

function renderChat(messages, isLiveUpdate) {
  chatList.replaceChildren(chatEmpty);
  chatEmpty.hidden = messages.length > 0;
  messages.forEach((message) => {
    if (isLiveUpdate && !seenChatIds.has(message.id) && voiceToggle.checked) {
      speechQueue.speak(`${message.name} dice: ${message.text}`);
    }
    seenChatIds.add(message.id);
    const row = document.createElement('article');
    row.className = 'host-chat-message';
    const header = document.createElement('div');
    header.className = 'host-chat-message-header';
    const name = document.createElement('strong');
    name.textContent = message.name;
    const time = document.createElement('time');
    time.dateTime = message.timestamp;
    time.textContent = new Intl.DateTimeFormat('es', { hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).format(new Date(message.timestamp));
    const text = document.createElement('p');
    text.textContent = message.text;
    header.append(name, time);
    row.append(header, text);
    chatList.append(row);
  });
  chatList.scrollTop = chatList.scrollHeight;
}

async function unlockHost(session) {
  if (!session || session.role !== 'host') throw new Error('Esta cuenta no tiene permisos de host.');
  isHost = true;
  hostSession.textContent = session.user.toUpperCase();
  hostLogin.hidden = true;
  hostLayout.hidden = false;
  hostPassword.value = '';
  resetButton.disabled = false;
  roundControl.disabled = false;
  renderVoiceOptions(spanishVoices);
  chatInput.disabled = false;
  chatSend.disabled = false;
  chatStatus.textContent = 'Conectado al chat';
  capacityInput.disabled = false;
  capacitySubmitBtn.disabled = false;
  capacityClearBtn.disabled = false;
  capacityPresetBtns.forEach((btn) => { btn.disabled = false; });
  await refreshCameras();
  updateHostAudioUI();
  if (!localCameraStream && !hostVideo.src) {
    connectLocalCamera();
  }
}

async function refreshCameras() {
  if (!navigator.mediaDevices?.enumerateDevices) {
    cameraNote.textContent = 'Este navegador no permite acceder a cámaras locales.';
    cameraButton.disabled = true;
    return;
  }

  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const cameras = devices.filter((device) => device.kind === 'videoinput');
    const selectedId = cameraSelect.value;
    cameraSelect.replaceChildren();
    cameras.forEach((camera, index) => {
      const option = document.createElement('option');
      option.value = camera.deviceId;
      option.textContent = camera.label || `Cámara ${index + 1}`;
      cameraSelect.append(option);
    });
    const obsCamera = cameras.find((c) => /obs|virtual/i.test(c.label));
    if (selectedId && cameras.some((camera) => camera.deviceId === selectedId)) {
      cameraSelect.value = selectedId;
    } else if (obsCamera) {
      cameraSelect.value = obsCamera.deviceId;
    }
    cameraSelect.disabled = cameras.length === 0;
    cameraButton.disabled = cameras.length === 0 || Boolean(localCameraStream);
    if (!cameras.length) cameraNote.textContent = 'No se detectan cámaras. Activa OBS Virtual Camera y vuelve a intentarlo.';
    else cameraNote.textContent = 'Señal de OBS lista para previsualizar y transmitir.';
  } catch {
    cameraNote.textContent = 'No se pudo consultar la lista de cámaras.';
  }
}

function updateHostAudioUI() {
  const isMuted = hostVideo.muted || hostVideo.volume === 0;
  if (hostAudioIcon) hostAudioIcon.textContent = isMuted ? '🔇' : '🔊';
  if (hostAudioLabel) hostAudioLabel.textContent = isMuted ? 'Activar sonido' : 'Silenciar';
  if (hostAudioButton) hostAudioButton.classList.toggle('unmuted', !isMuted);
}

async function connectLocalCamera() {
  if (!isHost || !navigator.mediaDevices?.getUserMedia) return;
  cameraButton.disabled = true;
  cameraNote.textContent = 'Solicitando acceso a la cámara…';
  try {
    const deviceId = cameraSelect.value;
    const video = deviceId ? { deviceId: { exact: deviceId } } : true;
    let stream = null;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video, audio: true });
    } catch {
      stream = await navigator.mediaDevices.getUserMedia({ video, audio: false });
    }
    if (localCameraStream) localCameraStream.getTracks().forEach((track) => track.stop());
    localCameraStream = stream;
    hostVideo.srcObject = stream;
    hostVideo.muted = true;
    hostVideo.playsInline = true;
    await hostVideo.play();
    const activeDeviceId = stream.getVideoTracks()[0]?.getSettings().deviceId;
    if (activeDeviceId) cameraSelect.value = activeDeviceId;
    videoPlaceholder.hidden = true;
    streamStatus.textContent = 'Cámara local / OBS conectada';
    cameraNote.textContent = 'Señal de OBS activa en tiempo real.';
    cameraSelect.disabled = true;
    cameraButton.hidden = true;
    cameraStopButton.hidden = false;
    updateHostAudioUI();
    await refreshCameras();
  } catch (error) {
    cameraButton.disabled = false;
    cameraNote.textContent = error.name === 'NotAllowedError'
      ? 'Permite el acceso a la cámara en el navegador.'
      : 'No se pudo conectar. Comprueba que OBS Virtual Camera esté activa.';
  }
}

function disconnectLocalCamera() {
  if (localCameraStream) localCameraStream.getTracks().forEach((track) => track.stop());
  localCameraStream = null;
  hostVideo.srcObject = null;
  videoPlaceholder.hidden = false;
  streamStatus.textContent = 'Sin señal configurada';
  cameraButton.hidden = false;
  cameraStopButton.hidden = true;
  updateHostAudioUI();
  refreshCameras();
}

if (hostAudioButton) {
  hostAudioButton.addEventListener('click', async () => {
    if (hostVideo.muted) {
      hostVideo.muted = false;
      try {
        await hostVideo.play();
      } catch {
        hostVideo.muted = true;
      }
    } else {
      hostVideo.muted = true;
    }
    updateHostAudioUI();
  });
}

hostVideo.addEventListener('volumechange', updateHostAudioUI);

cameraButton.addEventListener('click', connectLocalCamera);
cameraStopButton.addEventListener('click', disconnectLocalCamera);
cameraSelect.addEventListener('change', () => {
  if (localCameraStream) connectLocalCamera();
  else cameraButton.disabled = !cameraSelect.value;
});

hostLoginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  hostLoginError.textContent = '';
  try {
    await unlockHost(await window.Ludito.authenticateAdmin(hostPassword.value));
  } catch (error) {
    hostLoginError.textContent = error.message;
    hostPassword.setAttribute('aria-invalid', 'true');
    hostPassword.focus();
  }
});

resetButton.addEventListener('click', () => {
  if (!isHost || resetButton.disabled) return;
  if (resetModal) {
    resetModal.hidden = false;
  }
});

if (resetCancel) {
  resetCancel.addEventListener('click', () => {
    if (resetModal) resetModal.hidden = true;
  });
}

if (resetModal) {
  resetModal.addEventListener('click', (event) => {
    if (event.target === resetModal) resetModal.hidden = true;
  });
}

// Action 1: Reset Entire Live Session (Chat, Orders, Rounds)
if (resetConfirm) {
  resetConfirm.addEventListener('click', async () => {
    if (!isHost) return;
    resetConfirm.disabled = true;
    if (resetChatOnly) resetChatOnly.disabled = true;
    resetButton.disabled = true;
    resetStatus.textContent = 'Limpiando chat y reiniciando sesión…';
    speechQueue.clear();
    seenChatIds.clear();

    try {
      const result = await window.Ludito.resetLiveState();
      renderState(result.state);
      chatList.replaceChildren(chatEmpty);
      chatEmpty.hidden = false;
      if (resetModal) resetModal.hidden = true;
      resetStatus.textContent = `Listo: chat limpiado (${result.removedChatMessages} mensajes) y pedidos reiniciados. Ronda 1 abierta.`;
    } catch (error) {
      resetStatus.textContent = error.message;
    } finally {
      resetConfirm.disabled = false;
      if (resetChatOnly) resetChatOnly.disabled = false;
      resetButton.disabled = !isHost;
    }
  });
}

// Action 2: Clear Chat Only
if (resetChatOnly) {
  resetChatOnly.addEventListener('click', async () => {
    if (!isHost) return;
    if (resetConfirm) resetConfirm.disabled = true;
    resetChatOnly.disabled = true;
    resetButton.disabled = true;
    resetStatus.textContent = 'Limpiando mensajes del chat…';
    speechQueue.clear();
    seenChatIds.clear();

    try {
      const result = await window.Ludito.clearChat();
      renderState(result.state);
      chatList.replaceChildren(chatEmpty);
      chatEmpty.hidden = false;
      if (resetModal) resetModal.hidden = true;
      resetStatus.textContent = `Listo: ${result.removedChatMessages} mensajes de chat eliminados.`;
    } catch (error) {
      resetStatus.textContent = error.message;
    } finally {
      if (resetConfirm) resetConfirm.disabled = false;
      resetChatOnly.disabled = false;
      resetButton.disabled = !isHost;
    }
  });
}

window.Ludito.restoreAdminSession().then((session) => {
  if (!session || isHost) return;
  unlockHost(session).catch((error) => {
    window.Ludito.logout();
    hostLogin.hidden = false;
    hostLoginError.textContent = error.message;
  });
});

voiceSelector.addEventListener('change', async () => {
  if (!isHost) return;
  const voice = spanishVoices.find((candidate) => candidate.voiceURI === voiceSelector.value);
  const preference = voice
    ? { voiceURI: voice.voiceURI, lang: voice.lang, name: voice.name, volume: Number(voiceVolume.value) }
    : { voiceURI: '', lang: 'es-MX', name: 'Automática (español)', volume: Number(voiceVolume.value) };
  voicePreference = preference;
  speechQueue.setVoicePreference(preference);
  voiceSelector.disabled = true;
  try {
    await window.Ludito.saveVoicePreference(preference);
    streamStatus.textContent = `Voz seleccionada: ${preference.name}`;
  } catch (error) {
    streamStatus.textContent = error.message;
  } finally {
    voiceSelector.disabled = !isHost;
  }
});

let voiceSaveTimer = null;
voiceVolume.addEventListener('input', () => {
  const volume = Number(voiceVolume.value);
  voiceVolumeValue.value = `${Math.round(volume * 100)}%`;
  voiceVolumeValue.textContent = `${Math.round(volume * 100)}%`;
  voicePreference = { ...(voicePreference || {}), voiceURI: voicePreference?.voiceURI || '', lang: voicePreference?.lang || 'es-MX', name: voicePreference?.name || 'Automática (español)', volume };
  speechQueue.setVoicePreference(voicePreference);
  window.clearTimeout(voiceSaveTimer);
  voiceSaveTimer = window.setTimeout(async () => {
    try {
      await window.Ludito.saveVoicePreference(voicePreference);
    } catch (error) {
      streamStatus.textContent = error.message;
    }
  }, 180);
});

voiceTestButton.addEventListener('click', () => {
  speechQueue.speak('Hola. Esta es una prueba de la voz del chat en español.');
});

voiceToggle.addEventListener('change', () => {
  speechQueue.setEnabled(voiceToggle.checked);
});

window.Ludito.onSpanishVoicesChanged((voices) => {
  renderVoiceOptions(voices);
});

chatForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const message = chatInput.value.trim();
  if (!isHost || !message) return;
  chatInput.disabled = true;
  chatSend.disabled = true;
  try {
    await window.Ludito.sendChat(message);
    chatInput.value = '';
    chatStatus.textContent = 'Mensaje enviado.';
  } catch (error) {
    chatStatus.textContent = error.message;
  } finally {
    chatInput.disabled = !isHost;
    chatSend.disabled = !isHost;
    if (isHost) chatInput.focus();
  }
});

roundControl.addEventListener('click', async () => {
  if (!isHost || roundControl.disabled) return;
  roundControl.disabled = true;
  try {
    await window.Ludito.toggleRound();
  } catch (error) {
    streamStatus.textContent = error.message;
  } finally {
    roundControl.disabled = !isHost;
  }
});

capacityForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!isHost) return;
  const val = capacityInput.value.trim();
  const num = Number(val);
  if (!val || isNaN(num) || num <= 0) {
    capacityStatus.textContent = 'Ingresa una cantidad válida mayor a 0.';
    return;
  }
  capacitySubmitBtn.disabled = true;
  capacityStatus.textContent = 'Guardando espacios...';
  try {
    await window.Ludito.setRoundCapacity(Math.floor(num));
    capacityStatus.textContent = `Cupos fijados a ${Math.floor(num)} por color.`;
  } catch (err) {
    capacityStatus.textContent = err.message;
  } finally {
    capacitySubmitBtn.disabled = false;
  }
});

capacityClearBtn.addEventListener('click', async () => {
  if (!isHost) return;
  capacityClearBtn.disabled = true;
  capacityStatus.textContent = 'Quitando límite...';
  try {
    await window.Ludito.setRoundCapacity(null);
    capacityInput.value = '';
    capacityStatus.textContent = 'Pedidos libres activados (sin límite).';
  } catch (err) {
    capacityStatus.textContent = err.message;
  } finally {
    capacityClearBtn.disabled = false;
  }
});

capacityPresetBtns.forEach((btn) => {
  btn.addEventListener('click', async () => {
    if (!isHost) return;
    const val = Number(btn.dataset.capacity);
    capacityInput.value = String(val);
    btn.disabled = true;
    capacityStatus.textContent = `Fijando ${val} cupos por color...`;
    try {
      await window.Ludito.setRoundCapacity(val);
      capacityStatus.textContent = `Cupos fijados a ${val} por color.`;
    } catch (err) {
      capacityStatus.textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  });
});

window.Ludito.subscribe(renderState, (connected) => {
  document.querySelector('.host-live').dataset.connected = String(connected);
});
window.Ludito.fetchState().then(renderState).catch(() => { streamStatus.textContent = 'Servidor no disponible'; });
window.Ludito.fetchConfig().then((config) => {
  if (!config.streamUrl) return;
  hostVideo.src = config.streamUrl;
  hostVideo.addEventListener('playing', () => {
    videoPlaceholder.hidden = true;
    streamStatus.textContent = 'Señal conectada';
  });
  hostVideo.addEventListener('error', () => { streamStatus.textContent = 'No se pudo abrir la señal'; });
}).catch(() => { streamStatus.textContent = 'Servidor no disponible'; });

window.addEventListener('pagehide', () => {
  if (localCameraStream) localCameraStream.getTracks().forEach((track) => track.stop());
});
